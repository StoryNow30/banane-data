# Procédure de retour arrière — Banane 4.7.0

Le premier paquet 4.8.0 du 28/09 (`d3874290…`, depuis `a68201a`) n'est pas
une cible de retour : il garde KI-064 (Écho peut purger un nuage sans fichier
confirmé) ; il est remplacé par le paquet 4.8.0 corrigé après l'audit (D-059).

**Depuis Ariane 4.8.0, la cible de retour est Banane 4.7.21**, étiquette
`v4.7.21`, commit `ead1cd1` (paquet `banane-v4.7.21-test.zip`, SHA-256 `24f8f1fe…f4ee2c06`).
La 4.7.21 garde KI-063 (arrêts sur un ESV lent ou muet) ; ses données et
exports restent lisibles par la 4.8.0 (mêmes formats). Installer par-dessus,
sans supprimer l'extension.

```bash
git archive ead1cd1 | tar -x -C /tmp/banane-4.7.21
cd /tmp/banane-4.7.21 && python3 tools/package.py --output /tmp/banane-v4.7.21-test.zip
```

**Avant la 4.8.0, la dernière version éprouvée était la 4.7.20** (26/09, deux
lots Pilote : partie 12 menée à sa borne, partie 11). En cas de problème sur le
terrain avec la 4.7.21, revenir à la **4.7.20**, commit `f859d8f` (paquet
`banane-v4.7.20-test.zip`, SHA-256 `b3a679da…a3572f4cb`). Terminer ou arrêter le
lot en cours d'abord. La 4.7.20 garde KI-062 (après un lot arrêté, « Nouveau
lot » garde les bornes de l'ancien : saisir le premier cut à la main, celui
qu'ESV affiche) et les réglages du lot à cocher.

```bash
git archive f859d8f | tar -x -C /tmp/banane-4.7.20
cd /tmp/banane-4.7.20 && python3 tools/package.py --output /tmp/banane-v4.7.20-test.zip
```

**Depuis la 4.7.21**, la cible de retour est donc la **4.7.20**. La 4.7.21
corrige le démarrage d'un nouveau lot (KI-062), fixe les réglages du lot et
active le cerveau par défaut (D-056), ouvre les détails par défaut, retire
l'Assisté de l'interface et refait le mouvement. Le moteur et la décision sur le
lot (`lot-decision-v6`) ne changent pas : un lot se reprend d'une version à
l'autre.

**Depuis la 4.7.20**, la cible de retour est donc la **4.7.19**. La 4.7.20
change l'interface (piste H), ajoute le bandeau dans ESV, corrige l'écriture des
exports en segments (KI-060), constate la fin de partie (KI-061), refuse une
reprise après rechargement d'ESV et porte la garde des voisins validés (D-054,
sans source sur le terrain). Le moteur et la décision sur le lot
(`lot-decision-v6`) ne changent pas : un lot se reprend d'une version à l'autre.

**Depuis la 4.7.19**, la cible de retour est donc la **4.7.18**. La 4.7.19
ajoute le lecteur « passage à niveau » en dernier recours et la voie encadrée
(`lot-decision-v6`, D-053), le lot « Reprise des différés », l'arrêt au dernier
cut du lot et le correctif KI-059. Un lot « Reprise » repris en 4.7.18 perdrait
ses appuis de départ : terminer ou arrêter le lot d'abord.

Avant la 4.7.18, la version éprouvée était la **4.7.14**, commit `3e83fc4`
(paquet `banane-v4.7.14-test.zip`, SHA-256 `4ef4ca3e…12e56b8a`) ; les 4.7.15 à
4.7.17 n'ont jamais tourné sur ESV.

Les cibles ci-dessous restent valables version par version.

**Depuis la 4.7.18**, la cible de retour est la **4.7.17**, commit `e1bb7ef`
(paquet `banane-v4.7.17-test.zip`, SHA-256 `46094629…41fe7d`, reconstruit à
l'identique le 24/09). La 4.7.18 change la mémoire des appuis de la décision sur
le lot (un appui est un cut posé, D-052), refuse « Réessayer » après un
déplacement manuel des rails (KI-055) et consigne la version qui crée le lot ;
interface et commandes inchangées. Un lot commencé en 4.7.18 et repris en 4.7.17
repasserait à l'ancienne règle d'appui : terminer ou arrêter le lot d'abord.

```bash
git archive e1bb7ef | tar -x -C /tmp/banane-4.7.17
cd /tmp/banane-4.7.17 && python3 tools/package.py --output /tmp/banane-v4.7.17-test.zip
```

**Depuis la 4.7.17**, la cible de retour est la **4.7.16**, commit `155dbec`
(paquet `banane-v4.7.16-test.zip`, SHA-256 `5e23d35c…23f0b38b`). La 4.7.17 ne
change que l'interface : placement et commandes identiques.

```bash
git archive 155dbec | tar -x -C /tmp/banane-4.7.16
cd /tmp/banane-4.7.16 && python3 tools/package.py --output /tmp/banane-v4.7.16-test.zip
```

**Depuis la 4.7.16**, la cible de retour est la **4.7.15**, commit `d566fa8`
(paquet `banane-v4.7.15-test.zip`, SHA-256 `67632d96…4583ead3`). La 4.7.16 ne
change que deux règles de la décision sur le lot (garde d'écartement voisin
20 mm, choix à 5 points de dessus, D-050).

```bash
git archive d566fa8 | tar -x -C /tmp/banane-4.7.15
cd /tmp/banane-4.7.15 && python3 tools/package.py --output /tmp/banane-v4.7.15-test.zip
```

**Depuis la 4.7.15**, la cible de retour est la **4.7.14**, commit `3e83fc4`
(paquet `banane-v4.7.14-test.zip`, SHA-256 `4ef4ca3e…12e56b8a`). La 4.7.15 ne change
qu'un curseur de la décision sur le lot (`chainMm` 10 → 15 mm, D-047).

```bash
git archive 3e83fc4 | tar -x -C /tmp/banane-4.7.14
cd /tmp/banane-4.7.14 && python3 tools/package.py --output /tmp/banane-v4.7.14-test.zip
```

**Depuis la 4.7.14**, la cible de retour est la **4.7.13**, commit `71c262b`
(paquet `banane-v4.7.13-test.zip`, SHA-256 `c4fc1190…6422757c`). Attention : la
4.7.13 porte le défaut bloquant KI-053 ; « Observer seulement » l'évite.

```bash
git archive 71c262b | tar -x -C /tmp/banane-4.7.13
cd /tmp/banane-4.7.13 && python3 tools/package.py --output /tmp/banane-v4.7.13-test.zip
```

**Depuis la 4.7.13**, la cible de retour est la **4.7.12**, commit `7a2144c`
(paquet `banane-v4.7.12-test.zip`, SHA-256 `4c384981…252baa4`). La 4.7.13 ne
change que l'interface : placement et commandes identiques.

```bash
git archive 7a2144c | tar -x -C /tmp/banane-4.7.12
cd /tmp/banane-4.7.12 && python3 tools/package.py --output /tmp/banane-v4.7.12-test.zip
```

**Depuis la 4.7.12**, la cible de retour est la **4.7.11**, commit `d51c644`
(paquet `banane-v4.7.11-test.zip`, SHA-256 `6edee72d…73371a8`). La 4.7.12 n'y
ajoute que la garde de paire et la reprise après archivage.

```bash
git archive d51c644 | tar -x -C /tmp/banane-4.7.11
cd /tmp/banane-4.7.11 && python3 tools/package.py --output /tmp/banane-v4.7.11-test.zip
```

**Depuis la 4.7.11**, la cible de retour est la **4.7.10**, commit `69a554d`
(paquet `banane-v4.7.10-test.zip`, SHA-256 `4d2dbc02…3276000`) ; la 4.7.11 n'y
ajoute que le contrôle de la vue d'ESV avant commande (KI-051). Le réglage
« Observer seulement » reste le retour sans réinstaller.

```bash
git archive 69a554d | tar -x -C /tmp/banane-4.7.10
cd /tmp/banane-4.7.10 && python3 tools/package.py --output /tmp/banane-v4.7.10-test.zip
```

**Depuis la 4.7.10**, deux retours :

1. **Sans changer de version** : dans Réglages du lot, **Décision sur le lot :
   Observer seulement**, à la création du lot. Le Pilote est alors exactement
   celui de la 4.7.9 (un essai le vérifie : mêmes commandes).
2. **Retour à la 4.7.9**, commit `d6512f5` (paquet `banane-v4.7.9-test.zip`,
   SHA-256 `8054f1af…5ac43`) :

```bash
git archive d6512f5 | tar -x -C /tmp/banane-4.7.9
cd /tmp/banane-4.7.9 && python3 tools/package.py --output /tmp/banane-v4.7.9-test.zip
```

**Depuis la 4.7.9**, la cible de retour est la **4.7.8**, commit `5a204fa`
(paquet `banane-v4.7.8-test.zip`, SHA-256 `f32806b3…bd93`) :

```bash
git archive 5a204fa | tar -x -C /tmp/banane-4.7.8
cd /tmp/banane-4.7.8 && python3 tools/package.py --output /tmp/banane-v4.7.8-test.zip
```

La 4.7.9 ne change que l'ordre de chargement de la décision sur le lot et une
raison consignée (KI-048) : le placement du Pilote est identique.

**Depuis la 4.7.8**, la cible de retour est la **4.7.7**, commit `7a21a05`
(extension 4.7.7, documentation à jour) :

```bash
git archive 7a21a05 | tar -x -C /tmp/banane-4.7.7
cd /tmp/banane-4.7.7 && python3 tools/package.py --output /tmp/banane-v4.7.7-test.zip
```

La 4.7.8 n'ajoute à l'extension qu'un calcul consigné dans le Pilote, jamais
appliqué. Sans changer de version, il se coupe en passant `lot.observe` à
`false` dans `src/settings.js`.

**Depuis la 4.7.7**, la cible de retour est la **4.7.6**, commit `bd32245`
(extension identique à la 4.7.6, outils et documentation à jour) :

```bash
git archive bd32245 | tar -x -C /tmp/banane-4.7.6
cd /tmp/banane-4.7.6 && python3 tools/package.py --output /tmp/banane-v4.7.6-test.zip
```

La 4.7.7 ne change dans l'extension que l'observation « continuité » en Natif :
un calcul consigné, jamais appliqué. C'est ce retour que prévoit la règle
d'arrêt de D-036. Sans changer de version, l'observation se coupe en passant
`continuity.observe` à `false` dans `src/settings.js`.

**Depuis la 4.7.6**, la cible de retour est la **4.7.5**, commit `b9ef24f` :

```bash
git archive b9ef24f | tar -x -C /tmp/banane-4.7.5
cd /tmp/banane-4.7.5 && python3 tools/package.py --output /tmp/banane-v4.7.5-test.zip
```

La 4.7.6 ne change dans l'extension que le calage de convention des rails
publiés par GCV1. C'est ce retour que prévoit la règle d'arrêt de l'amendement
n°4 du cahier 4.8. Pour un essai ponctuel, `gcv1-shadow-configure` avec
`{convention:false}` coupe le calage jusqu'au prochain redémarrage du service
worker ; ce réglage n'est pas durable.

**Depuis la 4.7.5**, la cible de retour est la **4.7.4**, commit `ef90c8d` :

```bash
git archive ef90c8d | tar -x -C /tmp/banane-4.7.4
cd /tmp/banane-4.7.4 && python3 tools/package.py --output /tmp/banane-v4.7.4-test.zip
```

La 4.7.5 ne change dans l'extension que l'activation du flanc partiel dans le
Pilote. C'est ce retour que prévoit la règle d'arrêt de l'amendement n°3 du
cahier 4.8. Pour un essai ponctuel, la règle se coupe aussi dans le service
worker (`gcv1-shadow-configure` avec `{partialFlank:false}`), mais ce réglage
n'est pas durable : il revient actif à chaque redémarrage du service worker.

**Depuis la 4.7.4**, la cible de retour est la **4.7.3**, commit `e570f4a` :

```bash
git archive e570f4a | tar -x -C /tmp/banane-4.7.3
cd /tmp/banane-4.7.3 && python3 tools/package.py --output /tmp/banane-v4.7.3-test.zip
```

La 4.7.4 ne change dans l'extension que l'arrêt des lectures LiDAR après un
déplacement de rail par l'opérateur.

**Depuis la 4.7.3**, la cible de retour est la **4.7.2**, commit `d96543c` :

```bash
git archive d96543c | tar -x -C /tmp/banane-4.7.2
cd /tmp/banane-4.7.2 && python3 tools/package.py --output /tmp/banane-v4.7.2-test.zip
```

La 4.7.3 ne change que la fin de session Natif et la relance après une
modification de la découpe ESV.

**Depuis la 4.7.2**, la cible de retour est la **4.7.1**, commit `8199451` :

```bash
git archive 8199451 | tar -x -C /tmp/banane-4.7.1
cd /tmp/banane-4.7.1 && python3 tools/package.py --output /tmp/banane-v4.7.1-test.zip
```

La 4.7.2 ne change que la capture du mode Natif (lecteur, garde, relances,
service worker). Revenir en 4.7.1 ne change aucun placement ni aucune décision
du Pilote ; seule la capture Natif redevient celle qui perdait les visites
rapides.

**Depuis la 4.7.1**, build de mesure, la cible de retour est la release
officielle **4.7.0**, étiquetée `v4.7.0` :

```bash
git archive v4.7.0 | tar -x -C /tmp/banane-4.7.0
cd /tmp/banane-4.7.0 && python3 tools/package.py --output /tmp/banane-v4.7.0-test.zip
```

La 4.7.1 ne diffère de la 4.7.0 que par le coût de lecture du LiDAR : les points
retenus sont les mêmes, aucune science n'est touchée. Revenir en arrière ne
change donc aucun comportement, seulement le temps passé à lire.

Cible de retour depuis la **4.7.0** : **4.6.0**, checkpoint
`5e6d0e8b14ea880195672e5b9da914f046701e0c`. C'est la dernière version dont le
paquet a été réellement installé et utilisé dans Edge sur ESV.

Aucune donnée collectée n'est perdue par un retour arrière : les sessions vivent
dans IndexedDB, pas dans le code.

## 1. Reconstruire le paquet de la version précédente

Le dépôt ne conserve **aucune archive binaire** : `releases/` et `*.zip` sont
exclus par `.gitignore`. Le paquet de retour se reconstruit depuis Git, et il
est reproductible bit à bit :

```bash
git archive 5e6d0e8 | tar -x -C /tmp/banane-4.6.0
cd /tmp/banane-4.6.0 && python3 tools/package.py --output /tmp/banane-v4.6.0-test.zip
```

Contrôles attendus sur l'archive obtenue : **582 047 octets**, **94 entrées**,
`manifest.json` exactement une fois à la racine, aucun dossier parent, CRC OK.

Construire depuis `git archive` et non depuis un répertoire de travail : les
dates des entrées viennent alors du commit, ce qui rend l'empreinte du ZIP
reproductible. Un build depuis un clone donne le même contenu mais une autre
empreinte.

Réinstaller ensuite ce ZIP **dans le dossier déjà chargé par Edge**, recharger
l'extension dans `edge://extensions`, puis recharger la page ESV. Le panneau
doit afficher `V4.6.0 · TEST`.

## 2. Ce que le retour annule, et ce qu'il n'annule pas

La 4.7.0 ne diffère de 4.6.0 que par des chaînes de version et l'affichage de la
politique effective dans le panneau. **Tout le chemin de commande est identique
octet pour octet** : `src/engine.js`, `src/gauge.js`, `src/gcv1-shadow.js`,
`src/geometry.js`, `src/geometry-candidate-v1.js`, `src/adapter-page.js` et
`src/gcv1-export.js` sont les mêmes fichiers dans les deux versions.

Un retour de 4.7.0 vers 4.6.0 ne change donc **aucun comportement** : ni le
report des rails non résolus, ni le garde d'écartement, ni la navigation sans
décision, ni les exports. Il ne fait que revenir à un panneau qui n'annonce pas
la politique effective de faible confiance.

Pour revenir avant le report différé ou avant le garde d'écartement, il faut
remonter plus loin dans l'historique — ce sont des changements fonctionnels,
pas des changements d'affichage :

| Pour revenir avant | Checkpoint |
|---|---|
| Affichage de la politique effective | `5e6d0e8` (4.6.0) |
| Garde d'écartement de paire | `4057f08` |
| Correctif d'ambiguïté S1 | `28654a7` |
| Correctif caméra / incident 3560 | `65fc065` |
| Report `DEFERRED_UNRESOLVED` | `7c9f76d` |

## 3. Fichiers gelés — contrôlés par le banc

Trois fichiers sont gelés à la référence 4.4.0 et vérifiés octet pour octet par
`tools/verify.cjs` contre `audit/v4.4.0-frozen-engine-hashes.json`, qui n'est pas
modifiable :

| Fichier | SHA-256 |
|---|---|
| `src/geometry.js` | `3343330ee03fab4a20d3d2940fcb32e04ab1d4b912e3acd5f1e6cf8d7f854a53` |
| `vendor/capture-core.js` | `2bc4a70b7ce5d08990875804edea0a2097c0503a3d433a40b4eaeeb4ffd77054` |
| `vendor/lidar.js` | `375f7dfb932143027e2c814f78bf3d66d5fbda5eb97f323735e3fd4932de6311` |

La science GCV1, `src/geometry-candidate-v1.js`, est figée de la même façon à
`77f017669112a38b998a010f100ae681e7624ca864150bd592122a22422e7503`.

`src/engine.js` **n'est plus gelé à 4.4.0** : dégelé sur décision explicite en
V4.6.0, il est ré-épinglé sur `audit/v4.6.0-engine-baseline.json` et vaut
`be15576321f7a1bf7b0c727281b7f8a882eeea254382c83cf96590220740da33` en 4.7.0. Le
banc échoue sur toute dérive non déclarée.

## 4. Neutraliser sans désinstaller

Plutôt qu'un retour arrière, deux réglages suffisent le plus souvent :

- **Revenir au comportement historique des rails non résolus** : dans les
  réglages du lot, choisir « Mettre le lot en pause » avant de démarrer. La
  politique est figée à la création ; les lots déjà lancés ne changent pas.
- **Ne pas utiliser GCV1** : lancer un lot sans sélectionner le moteur
  `geometry-candidate-v1`. Le garde d'écartement du moteur reste actif — il est
  volontairement global — mais la science GCV1 n'est pas sollicitée.

Le garde d'écartement de paire n'a pas d'interrupteur, par construction : c'est
un invariant physique, pas une option.

## 5. Données déjà exportées

Les segments Natif restent au format `banane-native-session-v3-compact` et
restent lisibles après un retour arrière :

```bash
node tools/merge-segments.cjs --out session.json --dir dossier-des-segments
```

produit un export v2 ordinaire, accepté tel quel par `placement-lab.cjs` et
`native-offline-evaluate.cjs`. Conserver ce script même après un retour arrière
du reste, sinon les segments déjà écrits deviennent illisibles.

Les enregistrements `DEFERRED_UNRESOLVED` produits par 4.7 restent dans les
exports après un retour à 4.6.0, puisque le code d'export est identique. Un
retour plus ancien les rendrait illisibles par les outils de cette époque.
