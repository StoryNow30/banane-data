# BANANE 4.8 — SUPER CERVEAU + BANANE UI NEXT

Version du cahier : **2.0 — engagement 90 %** · **signé le 22 septembre 2026**
Base : `v4.7.0`, checkpoint `efe6bab5c1a27f3580f3c9f9cc643a36771ca98c`

Décision prise à la signature : **le chantier vitesse est reporté en 4.9.** La
4.8 porte le cerveau et l'interface. Concentrer l'effort sur la couverture plutôt
que de le partager entre deux objectifs qui se disputaient le même budget de
temps d'exécution.

Cette version remplace la 1.0, qui posait 90 % comme une cible non démontrée.
Elle pose 90 % comme un **engagement conditionnel** : une méthode qui y mène,
des préconditions qui deviennent des obligations, des jalons qui confirment ou
déclenchent un repli. Tout ajout ultérieur passe par un amendement (§16).

---

## 1. Frontière de version

**4.8 — Super cerveau + Banane UI Next.** Deux chantiers : la qualité de
placement, et l'interface opérateur.

**4.9 — Pilot Fast.** Le chantier vitesse, reporté à la signature. Sa première
tâche reste l'instrumentation par phase du pilote — capture, analyse, sélection,
clic, validation, navigation, chargement du nuage suivant — sans laquelle toute
optimisation serait une devinette. Un chargement Potree long a été observé sur le
lot réel : il se peut que le temps dominant ne soit pas dans l'orchestration
Banane du tout.

**5.0 — Multi-session, multi-onglets, multi-parties.**

---

## 2. L'engagement

> **90 % des cuts d'un lot traités avec les deux rails dans le contrat
> d'écartement, sans dégradation de la qualité de placement.**

Départ mesuré : 62 %. Il faut récupérer 21 cuts sur 74.

Cet engagement est **tenable** si les préconditions du §3 sont réunies. Elles ne
sont pas des souhaits : ce sont des obligations de projet, chacune avec son
jalon, son seuil et son repli. Un engagement sans préconditions nommées n'est
pas un engagement, c'est une espérance.

---

## 3. Pourquoi 90 % est atteignable — la méthode

### 3.1 Ce qui bloque aujourd'hui

**MESURÉ**, lot Edge du 21 septembre, 74 cuts, rejouable depuis
`tests/fixtures/gauge-part15-smoke.json`. Avec la 4.7 : 46 traités, 28 différés.

| Mode | Mécanisme | Poids |
|---|---|---:|
| **E1 — minimum parasite** | Le gabarit se verrouille sur la mauvaise surface ; les droites l'ajustent proprement ; confiance élevée, placement faux de 69 à 124 mm | 10 cuts |
| **E2 — famine du rail gauche** | 6 points de plan de roulement pour un seuil de 15 → abstention | 16 cuts |
| **E3 — ambiguïté réelle** | Deux placements concurrents plausibles | ~2 cuts |

### 3.2 Le défaut structurel

**ÉTABLI PAR LECTURE DU CODE.** La confiance publiée vaut :

```
100 × min(1, top/15, face/6, binsTop/5, binsFace/3) × exp(−résidu/0,006)
```

Nombre de points, couverture, résidu. **Aucun terme ne dit si la surface ajustée
est la bonne.** Elle répond à « ai-je ajusté proprement un plan ? », jamais à
« ce plan est-il le champignon ? ». D'où un candidat faux de 78 mm publié à
confiance 78.

Le garde d'écartement est aujourd'hui le **seul contrôle utilisant une
information de paire**. Le pipeline par rail ne peut structurellement pas la voir.

### 3.3 Le levier : la bonne réponse est probablement déjà calculée

**ÉTABLI PAR LECTURE DU CODE**, et c'est le fondement de l'engagement.

`propose()` balaie une grille de ±80 × ±40 mm au pas de 3 mm — environ
**1 400 positions par rail** — et conserve **toutes** leurs pertes dans `coarse[]`.
Une extraction de **tous les minima locaux** séparés de 20 mm existe déjà, écrite
et testée, derrière le drapeau `lab.multiMinima`.

Puis le moteur **jette tout sauf le minimum global**. Le critère
`lossRatio ≥ 1,5` ne compare que le meilleur au second.

Quand KI-032 mesure que 0 des 10 cuts hors contrat n'admettent de paire
admissible **dans le competitive set**, cela signifie : pas dans la bande des
1,5×. Cela ne dit **pas** que la bonne réponse est absente de la grille.

> **Hypothèse centrale : pour E1, la bonne position est présente parmi les
> minima locaux déjà calculés, mais mal classée par la perte de gabarit.**

Si elle est vraie, E1 cesse d'être un problème de recherche et devient un
problème de **classement** — qui se traite.

### 3.4 La recherche contrainte par la paire

La méthode qui porte l'engagement, et qui attaque E1 **et** E2 avec le même
mécanisme :

```
1. Énumérer les minima locaux de chaque rail        (code existant, lab.multiMinima)
2. Former les couples gauche × droite
3. NE GARDER que les couples dont l'écartement prévu est dans le contrat
4. Classer les couples survivants par un score de justesse appris
5. Publier si le score dépasse un seuil calibré, sinon s'abstenir
```

Ce que cela change :

**Le garde d'écartement devient un générateur, plus seulement un veto.** Au lieu
de refuser une paire fausse après coup, la contrainte physique **élimine d'emblée
les couples impossibles**. C'est de l'information gratuite, aujourd'hui inutilisée.

**E2 est attaqué par le même mécanisme.** Avec 6 points, le rail gauche ne peut
pas être placé indépendamment — mais connaissant le rail droit et le contrat, sa
position est fortement contrainte. On passe de *chercher* à *vérifier une
hypothèse*, ce qui demande beaucoup moins de points.

**La sécurité est renforcée, pas affaiblie.** Le garde final reste en place, et
l'abstention reste la sortie par défaut quand aucun couple ne convainc.

### 3.5 Un plancher qui ne dépend d'aucun apprentissage

Les étapes 1 à 3 sont **purement algorithmiques**. Le filtrage par contrat
d'écartement des couples de minima locaux ne demande ni données, ni modèle, ni
entraînement — uniquement du code déjà écrit.

> L'engagement repose donc d'abord sur un gain algorithmique, dont
> l'apprentissage est l'amplificateur — pas l'inverse.

C'est ce qui le rend tenable même si la collecte déçoit.

### 3.6 Ce que l'apprentissage ajoute

Le score de justesse du §2.4 étape 4. Il attaque directement le défaut du §2.2,
et il dispose du corpus le plus large : le vecteur de caractéristiques existe
déjà dans `metrics` — `topCount`, `faceCount`, `residual`, `binsTop`, `binsFace`,
`templateLoss`, `lossRatio`, `separation`, `alternative` — auquel s'ajoute
l'écartement de la paire. L'étiquette d'erreur est disponible sur **les 91
corrections** et pas seulement sur les 22 rejouables, parce que l'écartement est
une distance et non un rejeu.

C'est aussi lui qui rend **sûr** le desserrage de `minTop` : un ajustement affamé
mais juste devient distinguable d'un affamé et faux.

---

## 4. Préconditions de l'engagement

Chacune est une **obligation**, avec son jalon, son seuil et son repli. Si toutes
sont tenues, 90 % est promis. Si l'une tombe, le repli correspondant s'applique
et l'engagement est renégocié par amendement — pas abandonné en silence.

### P0 — L'expérience décisive *(jalon : avant tout développement)*

Rejouer GCV1 sur les 10 cuts hors contrat, grille conservée, minima locaux
énumérés sur les deux rails. Question unique : **existe-t-il un couple de minima
dont l'écartement est dans le contrat et qui tombe près de la correction
humaine ?**

| Résultat | Conséquence |
|---|---|
| Oui sur ≥ 7 des 10 | E1 est un problème de classement. **90 % est promis.** |
| Oui sur 3 à 6 | Engagement révisé à 85 %, méthode inchangée |
| Oui sur < 3 | E1 est un problème de génération. **Repli à 84 %**, et la génération d'hypothèses passe en recherche 4.9 |

Coût : les nuages des 10 cuts et du code déjà écrit. **Quelques heures.** C'est le
jalon le moins cher et le plus déterminant du programme ; rien ne démarre avant.

### P1 — Diagnostic du rail gauche *(jalon : avant la collecte complète)*

Un export de session dans `tools/diagnose-asymmetry.cjs`. Détermine si les 6
points contre 43–50 tiennent à la capture — ROI, clipping, niveau de détail,
occultation — ou à la géométrie du moteur.

**Repli** : si la cause est en amont, la priorité bascule du cerveau vers la
chaîne d'acquisition. Le chantier reste, son instrument change. Un modèle
entraîné sur des données affamées ne corrige pas une capture défaillante.

### P2 — Plancher de reproductibilité humaine *(jalon : pendant la collecte)*

**Aucune cible d'erreur n'est interprétable sans lui.** L'étiquette est la
correction de l'opérateur, et sa variance propre n'a jamais été mesurée. Si le
même opérateur replace le même champignon à 3 mm près, aucun modèle ne descendra
sous 3 mm.

Protocole, à intégrer à la collecte : un échantillon d'au moins **30 cuts
replacés en aveugle**, par le même opérateur à quelques jours d'écart ou par deux
opérateurs. On en tire l'écart-type de la référence, qui devient le **plancher
déclaré** de toute cible de qualité.

S'y ajoute que `physicalCalibrationStatus` n'atteste pas les millimètres : les
unités sont des unités de scène. Toute cible en millimètres hérite de cette
incertitude et doit le dire.

### P3 — Volume de collecte *(jalon : fin de collecte)*

| Usage | Minimum | Confortable |
|---|---:|---:|
| Score de justesse — modèle à ~15 caractéristiques | 300 rails exploitables | 600 |
| Régresseur de position | 1 000 rails | — |

**Repli sous 150 rails** : la piste apprise n'est pas engagée. On livre la
recherche contrainte par la paire avec un classement déterministe réglé à la
main — le plancher du §3.5, qui ne demande aucune donnée.

**Le régresseur de position n'est pas engagé en 4.8.** Le volume requis est hors
d'atteinte du calendrier. Le cerveau 4.8 **classe** ; il ne régresse pas.

### P4 — Taux de qualification *(jalon : avant la collecte complète)*

Aujourd'hui **24 %** : 22 exemples retenus sur 91. Sept conditions doivent tenir
ensemble, dont une fenêtre de lecture de la référence humaine de **1 500 ms** et
l'exigence d'une **intention unique**.

Collecte pilote de 15–20 cuts, lecture de l'histogramme `exclusionCauses` que
`tools/native-offline-evaluate.cjs` produit déjà. **Seuil exigé : 60 %.** En
dessous, on corrige le protocole ou le seuil avant d'engager la collecte
complète — sinon P3 est hors d'atteinte par simple arithmétique.

### P5 — Dénominateur des mauvais placements *(jalon : premier lot 4.8)*

Depuis le garde d'écartement, les mauvais placements résiduels sont ceux qui le
**franchissent** : erreurs common-mode conservant l'écartement. **Leur taux n'a
jamais été compté.** On ne réduit pas de 90 % une quantité non mesurée.

Mesure : erreur résiduelle des placements acceptés contre correction humaine,
rail par rail, sur un lot post-4.7. Sans elle, l'objectif « −90 % de mauvais
placements » reste sans dénominateur et n'est pas engageable.

### P6 — Budget d'inférence *(jalon : avant tout code A2)*

Le chantier vitesse est reporté, mais le budget reste — et sa raison change. Un
cerveau lent rend le pilote pénible quoi qu'il arrive, et la 4.9 ne doit pas
hériter d'une régression qu'elle ne pourra pas rattraper.

**Budget fixé d'avance : 150 ms par cut, les deux rails compris.** Au-delà, A2
n'entre pas en production 4.8, quelle que soit sa qualité.

---

## 5. Chantiers

### 5.1 Contrat de placement — commun à toutes les pistes

```
entrée  : capture LiDAR du cut + contexte géométrique
sortie  : par rail — delta, score de justesse, ou ABSTENTION motivée
          par paire — écartement prévu
```

L'abstention reste une sortie **de premier rang** : un modèle qui ne sait pas
doit le dire. Aucune sortie ne contourne le garde d'écartement. Toute sortie est
**rejouable à l'identique**.

### 5.2 Banc d'évaluation unique

Un seul banc score n'importe quelle implémentation du contrat : couverture,
distribution d'erreur par rail, interceptions conservées, abstentions par cause,
comparaison directe à GCV1 **sur les mêmes entrées**.

Règle de comparaison : « surpasse GCV1 » se mesure à abstentions comptées. Un
modèle qui s'abstient moins mais place plus mal ne surpasse rien.

Toute revendication chiffrée passe par ce banc.

### 5.3 Chantier A — le cerveau

**A0 — Recherche contrainte par la paire.** Le §3.4, étapes 1 à 3. Activation et
production du code `multiMinima` existant, génération des couples, filtrage par
contrat. Aucune donnée requise. **C'est le socle, et il est livré en premier.**

**A1 — Score de justesse appris hors ligne.** Le §3.4 étape 4. Caractéristiques
déjà calculées, déploiement des seuls coefficients, aucune dépendance, aucun coût
runtime. **Première cible de l'apprentissage — pas la position.**

**A2 — Inférence embarquée.** Seule voie si P1 montre que le plan de roulement
gauche doit être trouvé autrement que par l'extracteur géométrique. Contraintes :
service worker MV3, **aucun code hébergé à distance**, poids dans le paquet,
première dépendance externe du dépôt, budget P6.

**Couplage.** A2 génère des hypothèses, A1 les classe, le garde vérifie la paire.
Retenu seulement s'il est mesuré supérieur à chaque piste seule.

### 5.4 Chantier B — Banane UI Next

Interface **opérateur**, plus de laboratoire : état du pilote, rail et côté
traités, proposition ou absence, statut de validation ou de SKIP, anomalie, et
les seules commandes nécessaires. Diagnostic replié mais accessible. Compacte,
lisible, discrète dans ESV.

Modèle une-fenêtre-quatre-vues **conservé** : il a réglé de vrais problèmes.

Conservé de 4.7 : politique effective affichée, `Différés : N` fidèle à la
finalisation durable, incertitude de navigation visible avec son cut, aucun
bouton présenté comme réussi sur un simple accusé.

### 5.5 Chemin des commandes — règle conservée

Même sans chantier vitesse, la règle vaut pour tout code 4.8 : **boutons DOM
conservés**. Ils se vérifient avant d'agir — présence, `disabled` — alors qu'un
`KeyboardEvent` synthétique ne prouve pas sa prise en compte (défaut 6
d'`AUDIT_PILOTE.md`). Le passage aux touches `D` et `Maj+Espace` relève de la 4.9
et de sa mesure.

---

## 6. Critères d'acceptation

**C1 — Couverture.** ≥ 90 % des cuts avec les deux rails dans le contrat, sous
réserve du résultat de P0.

**C2 — Non-régression.** Distribution d'erreur non dégradée face à 4.7, médiane
**et** queue haute rapportées. Une médiane qui s'améliore pendant que la queue
enfle est un échec. Le plancher P2 est rappelé à côté de tout chiffre d'erreur.

**C3 — Interceptions conservées.** Les 10 cas hors contrat connus restent
interceptés. Une régression ici annule C1 quel qu'en soit le niveau.

**C4 — Mauvais placements.** −90 % par rapport au dénominateur établi en P5.

**C5 — Desserrage mesuré.** Chaque curseur du §8 reçoit son bilan chiffré ; ceux
que la mesure soutient sont desserrés. Un curseur conservé sans bilan est un
manquement, pas une prudence.

**C1 sans C2 et C3 ne vaut rien.** « Moins de différés » seul se satisfait en
publiant n'importe quoi.

---

## 7. Invariants de correction — intouchables

Non par principe : **les affaiblir ne rend aucun cut de plus et ne gagne aucune
seconde.** Ce ne sont pas des arbitrages couverture/qualité, ce sont des
conditions de correction. Les baisser ne produit que des échecs silencieux.

1. Contrat d'écartement `[1405, 1470] mm`, critère d'admissibilité — jamais une
   cible à viser. « Le candidat le plus proche de 1435 » ne sera jamais implémenté.
2. Les deux étages du garde restent en place et indépendants.
3. Aucune application partielle.
4. Aucun auto-SKIP.
5. Aucun rejeu ; au plus une émission physique par opération.
6. Contrôles d'identité et de cible avant toute commande.
7. Une navigation observée n'est jamais une confirmation serveur.
8. `reconcileRequired` ferme toute écriture sur un état incertain.
9. Les deux verdicts de transition VALIDATE restent inchangés.
10. `DEFERRED_UNRESOLVED` et son protocole durable restent intacts.

**L'abstention reste légitime.** On réduit les différés en donnant au moteur de
quoi décider — pas en lui interdisant de se taire.

---

## 8. Curseurs — desserrés sur mesure

Les vrais garde-fous au sens de l'ordonnance : ils arbitrent couverture contre
qualité, leur coût se mesure, les baisser est une décision ordinaire.

| Curseur | 4.7 | Coût mesuré aujourd'hui |
|---|---|---|
| `minTop` | 15 | Cause les 16 abstentions gauches |
| Competitive set `loss/lmin` | ≤ 1,5 | **Écarte peut-être la bonne réponse — P0 tranche** |
| Garde d'ambiguïté S1 | active | +1 abstention, −1 erreur > 50 mm, 0 erreur nouvelle |
| Seuil de confiance | neutralisé en Pilote GCV1 | 0 cut mis en pause pour cette cause sur 74 |
| Fenêtre de fraîcheur | 1 500 ms | Contribue au taux de 24 % |

Méthode : bilan chiffré sur le banc du §5.2, puis décision datée dans
`DECISIONS.md` portant la valeur retenue et son coût. On baisse sur un bilan — y
compris quand le bilan conclut qu'il faut baisser beaucoup.

**Le competitive set devient le curseur central du programme.** Si P0 confirme
l'hypothèse du §3.3, c'est lui qui écartait la bonne réponse, et la recherche
contrainte par la paire le remplace par un critère physique bien meilleur.

**Le contrat d'écartement n'est pas un curseur** : c'est la géométrie de la voie.
Son taux de faux refus mesuré est nul — 0 changement de classe sur 56 paires,
écart prévu/observé de 0,5253 mm au maximum. Élargissement possible, mais par
amendement portant une justification ferroviaire.

**Un garde ne place jamais rien : il refuse.** Les 10 paires hors contrat ont été
appliquées **puis validées** alors que le garde n'existait pas encore.

---

## 9. Gel géométrique

`src/geometry.js` est gelé à 4.4.0, vérifié octet pour octet par
`tools/verify.cjs`. **Dégel pré-autorisé** si les quatre conditions sont réunies :

1. P1 **démontre** que la cause est dans ce fichier ;
2. décision explicite et datée dans `DECISIONS.md`, comme pour `engine.js` en V4.6 ;
3. ré-épinglage sur `audit/v4.8.0-geometry-baseline.json`, qui recopie à
   l'identique les empreintes historiques 4.4.0 — elle ne peut pas assouplir le
   gel par la bande ; le banc échoue sur toute dérive non déclarée ;
4. effet mesuré avant/après sur le banc du §5.2.

`audit/v4.4.0-frozen-engine-hashes.json` n'est jamais modifié.

La science GCV1 — A_STAR, S1, seuils, pools, clusters, confidence — reste figée
sauf amendement adossé à une mesure. **La recherche contrainte par la paire
n'est pas une modification de cette science** : elle consomme des minima que le
moteur calcule déjà et n'en change ni le calcul ni les paramètres.

---

## 10. Données et provenance

Les lots existants et ceux collectés pour 4.8 sont
`DEVELOPMENT / TRAINING / REGRESSION_CONSUMED`. Ils ne seront **plus jamais**
présentés comme holdout indépendant.

Conservés systématiquement : provenance LiDAR, décisions du moteur, corrections
humaines, et le lien exact entre les trois.

Interdits : promotion automatique d'un `usableForTraining:false` ; entrée d'une
correction humaine dans l'entrée moteur ; association par proximité temporelle ;
capture LiDAR devinée.

---

## 11. Preuve et limite de revendication

**Aucun lot n'est réservé en aveugle.** Décision prise et assumée. Conséquence :

> Les chiffres de développement de 4.8 sont mesurés sur les données qui ont servi
> à régler le moteur. Ils ne démontrent pas la généralisation.

**Confirmation terrain.** Le premier lot 4.8 passé en Edge sur une partie non
utilisée pour l'entraînement fait office de validation aveugle — c'est de la
production, pas du réglage. Rapportée séparément, avec son effectif.

**C'est ce chiffre-là, et lui seul, qui vaut engagement tenu.**

Quatre niveaux de preuve, jamais confondus : contrôle de code, test simulé,
intégration locale, preuve terrain.

---

## 12. Livrables

1. **P0** — l'expérience décisive. Avant tout le reste.
2. **P1** — diagnostic du rail gauche.
3. **P4** — taux de qualification, avant la collecte complète.
4. **P2** — plancher de reproductibilité humaine.
5. **P5** — dénominateur des mauvais placements.
6. Banc d'évaluation unique.
7. **A0** — recherche contrainte par la paire. Le socle.
8. **A1** — score de justesse, mesuré.
9. **A2** — si P1 le justifie, dans le budget P6.
10. Couplage, retenu seulement s'il est mesuré supérieur.
11. Banane UI Next.
12. C1 à C5 sur le banc, plus la confirmation terrain du §11.
13. Bilan de chaque curseur du §8, valeurs retenues datées.
14. Known issues à jour, release reproductible selon la procédure 4.7.

---

## 13. Hors périmètre

- Régresseur de position appris — volume requis hors calendrier (P3).
- Rouvrir les audits fermés : GCV1 239, external24, S1 complet, Gauge complet,
  les 56 applications de la partie 15, support adaptive, No-Support Generator,
  Brain V2, pair arbitration V2.
- Retuner seuils, pools, clusters ou confidence sans bilan sur le banc.
- Choisir un écartement cible.
- Affaiblir un invariant du §7 — sans gain possible, par construction.
- Desserrer un curseur du §8 sans bilan chiffré et décision datée.
- Refondre le modèle de fenêtre.
- **Chantier vitesse — reporté en 4.9** par décision de signature, avec son
  instrumentation par phase et la question des raccourcis clavier.
- Multi-session, multi-onglets, multi-parties — c'est 5.0.

---

## 14. Tests d'acceptation

**A. Non-régression 4.7.** `DEFERRED_UNRESOLVED`, protocole durable et frontières
de crash, garde d'écartement à deux étages, VALIDATE, SKIP explicite, reprise
manuelle, G8.1, Observation, Assisté, Natif, Pilote normal : inchangés.

**B. Invariants.** Chacun des dix points du §7 a son essai.

**C. Curseurs.** Chaque valeur retenue est traçable jusqu'à son bilan. Un curseur
modifié sans bilan fait échouer la revue.

**D. Contrat de placement.** Abstention motivée plutôt que proposition devinée ;
sortie rejouable à l'identique.

**E. Recherche contrainte par la paire.** Aucun couple hors contrat n'est jamais
proposé ; le garde final reste actif et reste vérifié.

**F. Banc.** Mêmes entrées, mêmes scores d'une exécution à l'autre.

**G. Objectifs.** C1 à C5 rapportés ensemble. C1 seul n'est jamais présenté comme
un résultat. Le plancher P2 accompagne tout chiffre d'erreur.

**H. Interface.** Politique effective affichée, `Différés : N` fidèle, incertitude
visible avec son cut.

**I. Provenance.** Aucune fuite de correction humaine dans l'entrée moteur,
aucune promotion automatique.

---

## 15. Tableau de bord de l'engagement

| Précondition | Jalon | Seuil | Si non tenue |
|---|---|---|---|
| P0 — bonne réponse dans la grille | avant tout dev | ≥ 7/10 | 3–6 → 85 % · < 3 → 84 % et recherche en 4.9 |
| P1 — cause de la famine gauche | avant collecte | établie | priorité bascule vers la capture |
| P2 — plancher humain | pendant collecte | ≥ 30 cuts replacés | aucune cible d'erreur n'est publiée |
| P3 — volume | fin collecte | ≥ 300 rails | < 150 → classement déterministe seul |
| P4 — qualification | avant collecte | ≥ 60 % | protocole ou seuil corrigé avant de lancer |
| P5 — dénominateur | premier lot | mesuré | C4 non engageable |
| P6 — budget inférence | avant code A2 | ≤ 150 ms/cut | A2 hors production 4.8 |

*Le chantier vitesse étant reporté en 4.9, aucune précondition ne porte sur le
temps d'exécution du pilote en 4.8 — hors P6, qui protège la 4.9.*

---

## 16. Ce qui reste hors de portée de toute méthode

Si le rail gauche ne porte réellement que 6 points parce que la capture n'en
livre pas davantage, aucune architecture n'en invente — d'où P1.

`physicalCalibrationStatus` n'atteste pas les millimètres : unités de scène.

Aucune confirmation serveur ESV n'est disponible ; une navigation observée n'est
pas un enregistrement.

Le garde d'écartement ne couvre pas les erreurs common-mode conservant
l'écartement, ni les erreurs longitudinales.

---

## 17. Amendements

Le corps §1 à §16 est gelé en version 2.0.

Tout ajout ou modification prend la forme d'un amendement **numéroté et daté** :
ce qui change, pourquoi, quel élément nouveau le justifie, impact sur
l'engagement du §2 et sur le tableau du §15.

Un sujet qui n'est ni dans le corps ni dans un amendement est hors périmètre.

### Amendements enregistrés

- n°1 — doctrine de séquence et conséquences des premières mesures (22/09)
- n°2 — l'entrée du moteur, la densité, et le flanc (22/09) : corrige le §1.2 du n°1
- n°3 — flanc partiel activé dans le Pilote ; contexte de voie (22/09) : tranche le §2.5 du n°2, déroge au §1.5 du n°1 pour cette seule règle
- n°4 — audit 4.7.5 ; A1 redéfini en calage de convention (22/09) : remplace le §1.4 du n°1, mesure P5
- n°5 — validation du calage et bilan des curseurs (23/09) : précise la règle d'arrêt du §4.4 du n°4
- n°6 — premières mesures terrain de la 4.7.6 (23/09) : calage validé sur cuts inédits, P5 révisé, garde de continuité prioritaire
- n°7 — la logique de l'opérateur : partir de la continuité de la voie (23/09) : mesure l'amorce par continuité, confirme le §3.7 du n°3, élargit le chantier du §6.8 du n°6
- n°8 — première collecte 4.7.7 (23/09) : observation « continuité » mesurée sur le terrain, partie 24
- n°9 — décider sur le lot (23/09) : lève la règle « la prédiction ne fait que déplacer la fenêtre » (n°3 §3.5) pour le choix par la voie ; objectif intermédiaire 80 % ; définitions de mesure D-038
- n°10 — la décision sur le lot appliquée dans le Pilote (24/09) : relecture D-040, activation en un seul passage (D-041, D-042), vue d'ESV (D-043), garde de paire (D-044), interface « La ligne » (D-045) ; seuil C4 de sortie à trancher
- n°11 — bilan des curseurs de la décision sur le lot (24/09) : C5 pour les curseurs ajoutés par le n°9, `chainMm` desserré (D-047) ; relecture ciblée (D-048) ; cahier 4.9 ouvert (D-049) ; garde d'écartement voisin et `minTop` du choix (D-050)
- n°12 — relecture 4.7.16 et tests d'acceptation (24/09) : un appui est un cut posé (D-052, KI-057) ; « Réessayer » refusé après déplacement manuel (KI-055) ; C5 au rapport (KI-056) ; faux sans appui observés (D-051) ; conditions de la candidate
- n°13 — passages à niveau et reprise des différés (25/09) : ornière en dernier recours (D-053, KI-058) ; voie encadrée ; lot « Reprise » ; arrêt au dernier cut ; KI-059

## Amendement n°1 — doctrine de séquence et conséquences des premières mesures

**22 septembre 2026.** Élément nouveau : les mesures produites depuis la
signature, et la doctrine de séquence arrêtée par la direction.

### 1.1 Doctrine de séquence

> **Rendre l'observation saine → mesurer où le moteur échoue → introduire le
> plus petit apprentissage capable de corriger précisément cette classe
> d'erreur.**

Elle prime sur l'ordre des chantiers du §12. Aucun apprentissage n'est engagé
tant que l'étape qui le précède n'a pas rendu son chiffre.

### 1.2 « Observation saine » devient mesurable

Trois seuils, dont un indicateur nouveau qui agrège les autres.

| Indicateur | Mesuré le 22/09 | Seuil « sain » |
|---|---|---|
| Qualification de collecte (P4) | 61 % | ≥ 60 % — tenu |
| Flanc interne à la meilleure position | médiane 2 points | ≥ 6, cible 10 |
| **Taux de résolution** — rails résolus / rails qualifiés | **10 %** (4 sur 39) | **≥ 70 %** |

Le taux de résolution est l'indicateur de référence de l'étape 1. Tant qu'il
reste bas, « mesurer où le moteur échoue » revient à mesurer où il se tait :
ce n'est pas la même question et les conclusions ne se transportent pas.

### 1.3 La taxonomie d'échec sera refaite, pas réutilisée

Quand l'observation sera saine, la classe dominante actuelle — la famine du
flanc interne — disparaîtra. Ce qui restera relève de E1, les minima parasites
à 69–124 mm, et de la précision fine. La répartition par cause sera donc
reconstruite sur les nouvelles données, par le banc du §5.2.

Condition facile à oublier : mesurer où le moteur échoue exige des cas où il
échoue **et où la vérité est connue**. Cela ramène le taux de qualification et
le plancher P2 au premier plan.

### 1.4 A1 est redéfini — résultat négatif intégré

A0 mesuré sur le lot du 22 septembre : le classement déterministe par somme des
pertes normalisées retrouve le meilleur couple admissible **17 fois sur 17**.
C'est la contrainte d'écartement qui fait le travail, pas le classement.

**A1 tel que défini au §5.3 — « score de justesse pour classer les
hypothèses » — est sans objet.** Le classer n'a rien à gagner.

Mais A0 a testé le CLASSEMENT, pas la DÉCISION DE PUBLIER. Deux fonctions
distinctes :

- *lequel de ces couples est le meilleur ?* — résolu sans apprentissage ;
- *ce couple est-il assez bon pour être publié, ou faut-il s'abstenir ?* —
  **ouvert, et c'est là que vivent les erreurs de 69 à 124 mm.**

A1 devient donc un **modèle d'abstention** : prédire, à partir de `metrics`
déjà calculé, si le placement retenu s'écarte au-delà d'un seuil. Quelques
dizaines de coefficients, entrées existantes, aucune dépendance. Il attaque la
classe d'erreur qui coûte, et lui seul.

Il reste soumis à l'étape 1 de la doctrine : il n'est pas engagé avant que le
taux de résolution ait atteint son seuil.

### 1.5 P2 devient bloquant

A0 publierait à environ 5 mm par rail de la correction humaine. Savoir si c'est
préférable à une abstention est **indécidable** sans le plancher de
reproductibilité humaine. P2 passe de précondition à **blocage** : aucune
décision de publication, aucun seuil d'abstention, aucune cible d'erreur n'est
arrêtée avant sa mesure.

### 1.6 Inférence embarquée écartée du périmètre 4.8

La piste d'un réseau sur nuage de points — ranker et refiner appris, PyTorch,
export ONNX, exécution par ONNX Runtime Web — a été instruite puis écartée pour
la 4.8. Motifs retenus : l'entrée est affamée, et un modèle ne voit pas ce qui
n'a pas été capturé ; le socle géométrique que cette architecture suppose
fiable résout aujourd'hui 4 rails sur 39 ; le service worker MV3 est détruit
après environ trente secondes d'inactivité, si bien que le chargement du
runtime et des poids ne s'amortit pas sur un lot.

La piste n'est pas rejetée sur le fond : son architecture — géométrie, puis
couche apprise, puis arbitrage de paire, puis garde d'écartement, puis
application native — reste la bonne. Elle est reportée, et sa réouverture
demande un amendement adossé à l'atteinte du seuil de résolution du §1.2.

La piste A2 du §5.3 est suspendue en conséquence ; P6 reste en vigueur pour
toute reprise ultérieure.

## Amendement n°2 — l'entrée du moteur, la densité, et le flanc

**22 septembre 2026.** Éléments nouveaux : les collectes Natif 4.7.2 (partie 19,
105 visites) et 4.7.3 (partie 20, 67 visites), la session Pilote de la partie 18
et sa relecture native, et le rapport `tools/resolution-report.cjs`
(`audit/resolution-lots-2026-09-22.json`).

### 2.1 Correction du §1.2 de l'amendement n°1

« Flanc interne à la meilleure position : médiane 2 points » et « flanc ≥ 6
inatteignable avec ce capteur » étaient faux dans leur généralité. Deux
artefacts les produisaient :

- **la lecture Natif 4.7.0–4.7.1** s'arrêtait à chaque mouvement de caméra et
  plafonnait à ~106 000 points/s (corrigé en 4.7.2) ;
- **le banc ne donnait au moteur que le premier instantané qualifié**, déclenché
  dès qu'il y a juste assez de points pour dire « zone couverte ». La suite de la
  même lecture, même pose, avant toute action humaine, était stockée mais jamais
  utilisée.

Avec la lecture 4.7.2+ et l'entrée complète (§2.2) :

| Collecte | Points visibles par rail | Flanc médian | Rails flanc ≥ 6 | Rails résolus |
|---|---|---|---|---|
| 4.7.2, partie 19 | 826 | 6 | 93 / 174 | 50 % (17 % avec l'instantané seul) |
| 4.7.3, partie 20 | 2 138 | 12 | 105 / 111 | 74 % (50 % avec l'instantané seul) |

**La densité dépend de la partie** (données sources) : c'est elle, et non plus la
capture, qui fixe désormais le plafond du flanc. La densité chargée ne croît
quasiment pas pendant une visite (points en mémoire ×1,00 à ×1,04 en médiane
entre première et dernière lecture) : relire plus tard n'apporterait rien, et
n'est pas fait.

### 2.2 Entrée moteur du banc : la lecture complète de la pose de départ

L'entrée par défaut du banc (§5.2) devient l'instantané qualifié **plus la suite
de la même lecture** : même `captureId`, même côté, même pose de rail,
acquisition terminée avant la frontière — première correction observée du rail,
transition non attribuable ou intention de l'opérateur. La frontière anti-fuite
est inchangée : aucun point acquis après une action humaine n'entre.
`first-snapshot` reste disponible pour comparer. L'évaluateur historique 4.4 et
ses artefacts d'audit ne sont pas modifiés.

### 2.3 Étape 1 de la doctrine : seuil atteint sur une partie, pas sur l'autre

Taux de résolution sur données natives, hors ligne : **74 %** sur la partie 20,
**50 %** sur la partie 19, pour un seuil de 70 %. L'étape 1 n'est donc pas
déclarée franchie : le seuil doit tenir sur des parties de densités différentes,
au rythme réel.

Au niveau du cut (deux rails candidats, écartement dans le contrat) : partie 20,
37 cuts appliquables sur 55, **0 faux sur 29 jugés** (pire rail 5,8 mm) ; les 9
paires refusées par l'écartement contenaient toutes un rail faux de 47 à 200 mm.

### 2.4 Le Pilote lit déjà toute la zone chargée

Le Pilote lit, pour chaque vue de rail et après stabilisation du niveau de
détail, **tous** les points chargés dans la zone : ≈ 1 750 points par rail dans
la ROI, ≈ 875 visibles, sur la partie 18. Le gain du §2.1 venait de l'entrée du
banc, que le Pilote n'utilise pas. Le chantier « le Pilote lit comme le Natif »
envisagé le 22/09 est **annulé** : il n'apporterait rien au placement. Les
différés du Pilote sur les parties peu denses viennent d'un flanc de 3 à 5
points, réel.

### 2.5 Proposition « flanc partiel » : maintenue, non tranchée

Le retrait approuvé le 22/09 reposait sur la prémisse corrigée au §2.4. Re-mesurée
sur entrées complètes, la règle (flanc 3 à 5 points acceptés si le dessus a au
moins 15 points, pas de pente hors domaine, rapport de perte ≥ 1,5, deux rails
exigés, écartement dans le contrat, aucune autre garde touchée) donne :

| Jeu | Cuts appliqués | Avec la règle | Nouveaux jugés | Faux > 10 mm |
|---|---|---|---|---|
| Partie 19 (4.7.2) | 18 / 78 | 50 / 78 | 13 | 0 (pire 5,6 mm) |
| Partie 20 (4.7.3) | 37 / 55 | 39 / 55 | 2 | 0 |
| Lots 1–3 + Pilote partie 18 | — | +16 cuts | 14 | 0 (pire 4,3 mm) |

Le risque résiduel est inchangé : une erreur identique sur les deux rails passe
l'écartement. La proposition reste soumise au §1.5 (P2) et à la décision de la
direction.

### 2.6 Volume des collectes Natif

Les lectures LiDAR faites après un déplacement de rail **par l'opérateur** ne
nourrissent jamais le moteur ; elles faisaient 42 % des points exportés de la
collecte 4.7.3. Elles sont supprimées à partir de la 4.7.4
(`collector.captureAfterOperatorRailChange`, désactivé par défaut) ; un
ajustement des rails par ESV sans geste de l'opérateur reste lu.

### 2.7 Impact

Sur le §2 : l'engagement de 90 % n'est ni confirmé ni infirmé ; il dépend
désormais de la densité des parties et de la décision du §2.5. Sur le §15 : P4
tenu en Natif 4.7.2+ (82 à 87 % des rails avec instantané qualifié) ; P2 toujours
bloquant.

## Amendement n°3 — flanc partiel activé dans le Pilote ; contexte de voie

**22 septembre 2026.** Éléments nouveaux : la décision de la direction sur le
§2.5 ; la mesure du moteur réel avec et sans la règle sur les cinq collectes
(`audit/resolution-partial-flank-2026-09-22.json`) ; la session Pilote 4.7.4 de
la partie 20 et sa relecture Natif ; l'étude de continuité de voie
(`tools/continuity-study.cjs`, `audit/continuity-study-2026-09-22.json`).

### 3.1 Décision : flanc partiel actif dans le Pilote à partir de la 4.7.5

La direction tranche le §2.5 : **la règle est activée.** C'est une dérogation
explicite au §1.5 pour cette seule règle — P2 reste non mesuré ; la décision de
publier repose sur la mesure contre la relecture humaine (§3.2), pas sur un
plancher de reproductibilité. Le §1.5 reste en vigueur pour toute autre décision
de publication.

Mise en œuvre : `src/gcv1-shadow.js` passe l'option de laboratoire existante
`partialFaceKeep` à l'appel A_STAR. `src/geometry-candidate-v1.js` n'est pas
modifié (empreinte gelée) ; `minTop` 15, `minFace` 6 et le rapport de perte 1,5
restent les valeurs du contrat. Chaque proposition appliquée porte
`gcv1.partialFlankUsed` et `parameters.partialFlank`. Le retour durable est la
4.7.4 ; `gcv1-shadow-configure` avec `partialFlank:false` coupe la règle jusqu'au
prochain redémarrage du service worker, pour un essai.

**Règle d'arrêt.** Au premier cut appliqué par le Pilote avec un rail en flanc
partiel que la relecture Natif trouve faux de plus de 10 mm, la règle est
coupée et un amendement consigne le cas.

### 3.2 Mesure du moteur réel, règle inactive puis active

Mêmes données, même entrée (lecture complète de la pose de départ, §2.2), moteur
4.7.5 réglé dans les deux états :

| Collecte | Rails résolus | Cuts appliqués | Jugés | Faux > 10 mm | Pire rail |
|---|---|---|---|---|---|
| Lot 1, 4.7.0 | 15 % → 52 % | 1 → 6 | 6 | 0 | 5,4 mm |
| Lot 2, 4.7.1 | 16 % → 59 % | 0 → 11 | 8 | 0 | 4,0 mm |
| Lot 3, 4.7.1 | 19 % → 57 % | 0 → 7 | 4 | 0 | 4,0 mm |
| Partie 19, 4.7.2 | 50 % → 79 % | 18 → 50 | 23 | 0 | 6,5 mm |
| Partie 20, 4.7.3 | 74 % → 77 % | 37 → 39 | 31 | 0 | 5,8 mm |
| **Total** | | **56 → 113** | **72** | **0** | **6,5 mm** |

Au niveau du rail, la règle résout aussi des rails faux : 7 sur 194 jugés au-delà
de 10 mm (4 sur 130 sans la règle). **Aucun n'atteint l'application** : la paire
est exigée et l'écartement vérifié. La sûreté vient de ces deux gardes, pas de la
règle elle-même ; c'est pourquoi aucune d'elles n'est desserrée. Le risque d'une
erreur identique sur les deux rails, qui passe l'écartement, reste entier.

### 3.3 Étape 1 de la doctrine

Hors ligne, le seuil de 70 % est atteint sur les deux parties natives de densités
différentes : **79 %** (partie 19) et **77 %** (partie 20). Il n'est pas déclaré
franchi avant une session Pilote 4.7.5 relue en Natif : le Pilote lit ses propres
vues, et son taux de résolution terrain n'est pas encore mesuré.

### 3.4 Ce qui reste : les appareils de voie et contre-rails

Session Pilote 4.7.4, partie 20, cuts 126 à 138, tous relus en Natif : 2 cuts
appliqués (3 mm au plus de l'humain), 10 différés. Sur les 10, 8 sont refusés par
l'écartement — un rail posé sur une structure voisine à 65–192 mm, l'autre juste
à 4 mm près — et 2 par ambiguïté. Le flanc y est de 10 à 53 points : **ce n'est pas un
problème d'observation**, et le flanc partiel n'y change rien.

Cause : dans un appareil de voie, la pose initiale d'ESV est loin du rail — sur
chacun des 10 cuts différés, l'humain a déplacé au moins un rail de 62 à 115 mm. Le vrai rail est au bord ou hors de la
fenêtre de recherche de GCV1 (±80 mm autour de la pose initiale), et le meilleur
minimum dans la fenêtre est le contre-rail ou l'aiguille.

### 3.5 Contexte de voie — options explorées hors ligne

Question posée par la direction : le moteur peut-il mesurer la position et
l'écartement des rails aux cuts précédents et suivants pour placer ceux-ci ?

| Option | Résultat | Verdict |
|---|---|---|
| A0 : classer les couples par pertes, garder le meilleur admissible | 10 justes, 9 faux sur 19 cuts difficiles | écartée : publie des faux |
| Ancrer sur le rail sûr, reporter l'écartement du voisin | faux publiés | écartée ; et c'est une cible d'écartement (§3.6) |
| Prédire la position par les voisins **validés par l'humain** (±3 cuts) | erreur médiane 4,4 mm | indisponible au Pilote, qui n'a pas de validation en cours de lot |
| Prédire par les voisins **appliqués par le moteur** (±5 cuts), sans recherche | médiane 14 mm, max 25 mm | trop imprécis pour publier ; assez pour guider |
| **Recherche recentrée** : moteur gelé, fenêtre recentrée sur la prédiction des voisins moteur, résultat à ≤ 30 mm de la prédiction, paire + écartement | voir ci-dessous | **retenue pour la 4.8** |

Recherche recentrée, jugée contre la relecture humaine (options de laboratoire
existantes `uSeeds`, `recenterWindow`, `replaceOrigin`, flanc partiel) :

| Jeu | Cuts difficiles | Voisins des deux côtés (second passage) | Voisins précédents seuls (passage unique) |
|---|---|---|---|
| Natif 4.7.3, partie 20 | 12 | 7 justes · 0 faux · 5 différés | 4 justes · 0 faux · 8 différés |
| Relecture du Pilote 4.7.4, partie 20 | 7 | 5 justes · 0 faux · 1 différé · 1 sans référence | 3 justes · 0 faux · 3 différés · 1 sans référence |
| **Total** | **19** | **12 justes · 0 faux** | **7 justes · 0 faux** |

Limites, à lire avant toute conclusion :

- **une seule partie, un seul jour** : les 19 cuts viennent de la partie 20 ;
- **pire rail 9,2 mm** (9,5 mm en passage unique), près du seuil de 10 ; sur le
  lot 5, l'erreur gauche est positive sur les 7 cuts justes (+1 à +9 mm) et la
  droite négative sur 6 (jusqu'à −5,4 mm) : biais possible, à comprendre avant
  toute publication ;
- le passage unique manque les séries de cuts difficiles consécutifs (pas assez
  de voisins appliqués) : d'où le second passage ;
- une erreur de mode commun des voisins se propagerait au cut : la prédiction
  n'est jamais publiée seule, elle ne fait que déplacer la fenêtre.

### 3.6 Écartement des voisins : garde, jamais cible

L'écartement mesuré aux cuts voisins peut servir de **garde** — s'abstenir si
l'écartement du cut s'écarte de celui des voisins au-delà d'une tolérance à
mesurer — et jamais de **cible** : choisir, parmi des candidats, celui dont
l'écartement est le plus proche de celui des voisins est interdit au même titre
que « le plus proche de 1435 ». Dans un appareil de voie, l'écartement varie
lui-même (surécartement) ; la tolérance devra en tenir compte. Cette garde
n'attrape pas l'erreur de mode commun ; la continuité de position, oui. Elle est
proposée pour mesure en 4.8, sans engagement.

### 3.7 Nouveau chantier 4.8 : « contexte de voie »

Ajouté au §5, après le chantier A :

1. **Second passage** sur les cuts différés d'un lot Pilote : voisins appliqués
   des deux côtés, moteur gelé recentré, mêmes gardes (deux rails, écartement
   dans le contrat, acceptation à ≤ 30 mm de la prédiction). Pas de chaînage :
   un cut résolu par continuité ne sert pas de voisin.
2. Préalables à toute application : mesure sur au moins deux autres parties
   comportant des appareils de voie ; explication du biais de signe du §3.5 ;
   d'abord en observation dans le Pilote (calculé, consigné, non appliqué) sur
   un lot complet relu en Natif.
3. Même règle d'arrêt que le §3.1.

L'implémentation dans le Pilote demande un amendement adossé à ces mesures.

### 3.8 Impact

Sur le §2 : le taux de résolution hors ligne dépasse désormais 70 % sur les deux
parties natives ; l'engagement de 90 % reste ouvert et dépend des appareils de
voie (§3.4–3.7). Sur le §15 : P2 toujours non mesuré, et toujours bloquant hors
de la dérogation du §3.1 ; P4 tenu.

## Amendement n°4 — audit 4.7.5 ; A1 redéfini en calage de convention

**22 septembre 2026.** Éléments nouveaux : l'audit `AUDIT_CERVEAU_4.7.5.md`
(385 cuts, 7 sessions, parties 13, 18, 19, 20), ses outils
`tools/brain-audit.cjs` et `tools/convention-fit.cjs`, et leurs relevés
`audit/brain-audit-2026-09-22.json` et `audit/convention-fit-2026-09-22.json`.

### 4.1 Ce que l'audit établit

- **Le banc prédit le Pilote** : 23 décisions Pilote sur 23 reproduites à
  l'identique à partir de ses propres captures.
- **Aucun cut appliqué n'est faux** : 0 sur 76 jugés. Les 9 rails faux publiés
  (17 à 177 mm) sont tous arrêtés par l'exigence des deux rails, l'autre rail
  s'abstenant ; deux ne sont faux que de 17 mm, en deçà de ce que le contrat
  d'écartement peut voir.
- **Les placements appliqués sont biaisés** : latéral +2,1 mm côté champ sur
  chaque rail, vertical −2,8 mm, écartement +4,5 mm en médiane. Le moteur pose
  le gabarit au milieu de la bande de points, l'opérateur en enveloppe.
- **Quand le moteur s'abstient, la bonne position est calculée** pour 88 % des
  rails (minimum local à ≤ 10 mm) ; elle sort de la fenêtre pour 4 rails sur 105.
- **P2 reste non mesurable** (un seul cut commun à deux sessions) mais il est
  **borné** : le moteur calé reproduit l'humain à 1,6 mm latéral et 1,1 mm
  vertical en médiane ; le bruit humain ne peut pas dépasser cet écart.

### 4.2 P5 mesuré

Le dénominateur des mauvais placements (P5) est mesuré : **0 cut appliqué faux
au-delà de 10 mm sur 76 jugés**, erreur latérale médiane 2,4 mm (p90 5,0),
verticale 2,8 mm (p90 6,1). Au sens de C4, il n'y a aujourd'hui rien à réduire
de 90 % ; la qualité des placements se mesure par leur précision (C2), rapportée
avec sa médiane, sa queue et son biais.

### 4.3 A1 redéfini : calage de convention

Le §1.4 faisait d'A1 un modèle d'abstention. Mesuré, il n'a **rien à
apprendre** : aucune erreur appliquée à intercepter. La classe d'erreur qui
coûte est le biais de convention, présent sur 100 % des placements. Le plus
petit apprentissage qui la corrige est un **calage à deux constantes**,
`src/placement-convention.js` :

- dessus au 90e centile des points du dessus, + 1,0 mm ;
- flanc à la médiane des points du flanc, − 2,6 mm (côté voie) ;
- aucune correction latérale sous 6 points de flanc, aucun calage sous 15
  points de dessus ni au-delà de 8 mm de déplacement.

Validation en retenant chaque session à tour de rôle : latéral médian
2,39 → 1,60 mm, vertical 2,83 → 1,13 mm, écartement 4,67 → 2,34 mm (biais
+4,5 → +0,4 mm) ; aucun rail ne franchit 10 mm. Constantes stables d'une
session retenue à l'autre (dessus +0,6 à +1,2 ; flanc −2,1 à −2,8 mm).

### 4.4 Décision et périmètre

Le calage est **actif dans le build TEST 4.7.6**, au titre du mandat du 22/09
(« travaille sur le chantier selon les résultats de l'audit »). Il ne relève pas
du §1.5 : il ne fixe ni seuil d'abstention, ni cible d'erreur, ni décision de
publier, et le biais qu'il corrige se mesure indépendamment de P2 — une médiane
signée sur 185 rails ne dépend pas du bruit humain.

Il est appliqué au rail publié, après S1 et **avant** la garde d'écartement, qui
juge la paire calée. Il ne choisit aucun candidat, ne connaît pas l'autre rail,
ne vise aucun écartement ; un rail non résolu le reste. A_STAR, S1, les seuils,
`geometry-candidate-v1.js` et `engine.js` sont intacts. Chaque proposition
porte son delta brut (`gcv1.convention.rawDelta`). C'est une couche apprise
posée sur la science gelée, au sens de l'architecture du §1.6 — pas une
modification de cette science.

**Règle d'arrêt.** Sur la relecture Natif d'un lot Pilote 4.7.6 (au moins
20 rails jugés), si le placement calé est plus loin de l'humain que le
placement brut, en médiane latérale ou verticale, ou si un cut appliqué est
faux au-delà de 10 mm alors que le placement brut ne l'aurait pas été : retour
4.7.5 et amendement. Limite connue : en relecture, l'opérateur part du
placement calé ; un effet d'ancrage le favoriserait.

### 4.5 Suite, dans l'ordre

1. Mesure terrain du calage (lot Pilote 4.7.6 relu en Natif).
2. Continuité de voie (amendement n°3) : collectes d'autres parties avec
   appareils de voie.
3. Rails abstenus par manque de flanc alors que la bonne position est calculée
   (27 sur 41) : à instruire, en gardant en tête les rails faux de 17 mm que
   seule l'abstention de l'autre rail arrête aujourd'hui.
4. Temps moteur (médiane 152 ms, p90 758 ms par cut) : relevé pour la 4.9.

### 4.6 Impact

Sur le §2 : la couverture n'est pas modifiée par le calage ; la qualité l'est
(C2). Sur le §15 : P5 mesuré ; P2 borné mais toujours non mesuré ; P0 confirmé
sur les données d'observation saine (88 %).

## Amendement n°5 — validation du calage et bilan des curseurs

**23 septembre 2026.** Élément nouveau : KI-034, mesuré sur la partie 15 avant
cet audit — sur les cuts placés par le pilote, la retouche latérale de
l'opérateur vaut +0,23 ± 3,04 mm, alors que l'audit mesure un écart de 2,1 mm
par flanc contre des poses faites sans proposition.

### 5.1 La relecture d'un lot Pilote ne juge pas le calage

En relecture, l'opérateur part du placement proposé et ne retouche qu'au-delà de
sa tolérance. Une différence de 2 mm y reste invisible, dans un sens comme dans
l'autre. La règle d'arrêt du §4.4 de l'amendement n°4 est donc précisée :

- **la mesure qui fait foi** est une collecte Natif indépendante — l'opérateur
  pose depuis l'état ESV, sans proposition — sur une partie non utilisée pour
  l'ajustement, rejouée hors ligne calage actif puis coupé
  (`tools/brain-audit.cjs --convention on|off`) ;
- retour 4.7.5 si le calage y est plus loin de l'humain que le placement brut, en
  médiane latérale ou verticale, ou s'il rend faux au-delà de 10 mm un cut que le
  placement brut n'aurait pas rendu faux ;
- la relecture d'un lot Pilote reste utile pour la couverture réelle du Pilote et
  pour la règle d'arrêt du flanc partiel (erreurs au-delà de 10 mm, que la
  tolérance de l'opérateur ne masque pas).

Cette collecte vaut aussi confirmation terrain au sens du §11 pour le calage.

### 5.2 Bilan des curseurs

Le bilan exigé par C5 est consigné dans `DECISIONS.md`, D-035. En résumé : le
flanc est desserré (flanc partiel) ; `minTop`, le competitive set et la pente
sont conservés, avec leur coût mesuré. Desserrer le competitive set publierait 5
rails faux sur 12, et `minTop` n'a pas encore de bilan de desserrage : C5 reste
partiel sur ce point.

## Amendement n°6 — premières mesures terrain de la 4.7.6

**23 septembre 2026.** Éléments nouveaux : la collecte du 23/09 (`banane-data`,
`collections/2026-09-23_v4.7.6_/`) — un lot Pilote 4.7.6 sur la partie 19
(29 cuts) suivi de sa relecture Natif, et deux sessions Natif sur la partie 20
(cuts 107–995 et 1099–1154, 399 visites) ; les relevés
`audit/brain-audit-2026-09-23.json` et `audit/continuity-guard-2026-09-23.json`.
Les cuts 9033 et 9241 sont exclus du bilan à la demande de l'opérateur.

### 6.1 Le calage tient sur des cuts inédits

Partie 20 déjà vue, mais cuts jamais utilisés pour l'ajustement (le
chevauchement 126–140 est exclu) : c'est la mesure du §5.1 du n°5, sur une
partie connue et non sur une partie nouvelle.

| Cuts justes | Latéral médian | Vertical médian | Biais d'écartement |
|---|---|---|---|
| Natif long, 109 cuts : brut → calé | 2,8 → 1,3 mm | 3,1 → 0,7 mm | +4,9 → −0,2 mm |
| Natif court, 36 cuts : brut → calé | 2,5 → 0,9 mm | 2,9 → 0,9 mm | +4,9 → −0,5 mm |

Aucun cut n'est rendu faux par le calage ; un cut faux (397) est évité, son
écartement calé sortant du contrat. La règle d'arrêt n'est pas déclenchée : le
calage est maintenu. P2 est resserré : le bruit humain ne dépasse pas ≈ 1 mm
médian.

### 6.2 Le Pilote sur le terrain

Partie 19 : 15 cuts appliqués sur 29 (52 %), 14 différés, dont 12 où la pose ESV
de départ met le rail le plus décalé à 33–47 mm de la pose humaine (l'autre rail
à 0–34 mm). *Corrigé le 24/09 (relecture du chantier 4) : « 20–47 mm » mêlait les
deux rails. Au dénominateur D-038, défini ensuite, le lot compte 14 appliqués sur
28 cuts distincts (50 %) : 9407, atteint puis lot arrêté, y reste ; 9033 et 9241
sont exclus.* Le rejeu reproduit les 29 décisions
à l'identique, calage compris. Le cut 9047 est suspect et n'a pas été relu :
écartement appliqué 1 453,8 mm contre 1 434,6 mm pour ses voisins ; son rail
gauche était ambigu pour A_STAR (rapport de perte 1,05) et a été publié par S1.

### 6.3 P5 révisé : des cuts appliqués faux existent

Rejoué hors ligne sur la session Natif longue, le moteur 4.7.6 applique **8 cuts
faux sur 118 jugés** (6,8 %). Le « 0 sur 76 » du n°4 ne tient plus sur cette
partie :

- **6 décalages communs des deux rails**, de 117 à 273 mm (cuts 398 à 405 et
  435), écartement dans le contrat. Ils sont tous dans une zone en courbe où la
  pose ESV de départ est à 100–260 mm de la pose humaine : la vraie position est
  hors de la fenêtre de recherche, et le moteur trouve une autre paire cohérente.
  C'est le mode d'échec que le §16 déclare invisible à la garde d'écartement ;
- **1 rail posé 40 mm trop bas** (241), publié par S1, que le calage avait jugé
  hors domaine ;
- **1 rail à 15 mm** (983).

Aucun n'est dû au calage. La couverture parmi les cuts avec entrée est de 70 %
(178 sur 256) sur la session longue et 97 % (37 sur 38) sur la courte.

### 6.4 Flanc partiel

Sur la session longue, 18 cuts ne sont appliqués que grâce au flanc partiel :
10 justes, 6 sans référence, **2 faux** (405 et 435, dans la zone de décalage
commun : leur autre rail est faux aussi). La règle d'arrêt du n°3 §3.1 vise les
cuts appliqués par le Pilote et n'est pas déclenchée au sens strict. Le flanc
partiel n'est pas la cause de ces erreurs, mais il leur a ouvert la porte : son
maintien est lié à la garde du §6.6.

### 6.5 S1 repêche mal

Un rail qu'A_STAR laisse ambigu et que S1 publie est faux bien plus souvent :
2 sur 10 jugés le 22/09 contre 7 sur 184 pour les publications directes
d'A_STAR ; le 23/09, deux des cuts faux (241, 404) ont un rail repêché par S1, et
le cut suspect 9047 aussi. À instruire.

### 6.6 Garde de continuité : première mesure

Étude hors ligne (`tools/continuity-guard-study.cjs`) : chaque rail d'un cut
appliquable est comparé à la droite tirée des cuts précédents acceptés (6 cuts,
au moins 2) ; au-delà de 30 mm, le cut est différé et ne sert pas d'ancre. Sur la
partie 20 : **4 des 8 cuts faux arrêtés** (398, 404, 405, 435), **4 cuts justes
perdus sur 146**. Passent : 400 et 402, faute de cuts acceptés à proximité, 241
et 983. Garde, jamais cible : elle ne fait que différer.

### 6.7 Exports

83 % du volume exporté est de la répétition : chaque segment automatique
réécrit toutes les visites et tous les événements déjà exportés (1 651 Mo sur
1 989 Mo pour les 41 segments Natif ; les nuages LiDAR ne font que 338 Mo).

### 6.8 Ordre des suites

1. **Garde de continuité**, avant tout nouveau gain de couverture : traiter le
   cas « pas de cut accepté à proximité », mesurer sur d'autres zones, puis
   activer. Elle ne fait que différer : aucun invariant du §7 n'est touché.
2. **Exports allégés** : segments automatiques sans répétition des visites et
   des événements, et compression.
3. **S1** : instruire le repêchage des ambiguïtés, en commençant par 9047.
4. Le temps moteur monte à 1,1 s médian et 2,0 s au p90 par cut sur les
   captures denses de la partie 20 : relevé pour la 4.9.

Sur le §2 : couverture Pilote mesurée à 52 % sur la partie 19. Sur le §15 : P5
révisé (8 sur 118 hors ligne, partie 20) ; P2 resserré.

## Amendement n°7 — la logique de l'opérateur : partir de la continuité de la voie

**23 septembre 2026.** Élément nouveau : un export Natif de l'opérateur sur la
partie 22 (cuts 1196–1205, `banane-data`,
`collections/2026-09-23_v4.7.6_/natif p22 logique operateur/`), transmis pour
montrer comment il place un champignon en s'aidant de l'écartement des cuts
précédents ; l'étude `tools/continuity-seed-study.cjs` et son relevé
`audit/continuity-seed-2026-09-23.json`. Les cuts 9033 et 9241 restent exclus.

### 7.1 Ce que fait l'opérateur

Sur toute la série, chaque rail a un second champignon à 8–16 cm côté voie
(contre-rail ou appareil de voie), et la pose ESV de départ est un gabarit à
1 500 mm posé à 156–272 mm des rails. Relevé des gestes :

- deux clics par cut, rail gauche puis rail droit, 5 à 6 s par cut ; le second
  clic tombe à 5 mm au plus de l'écartement du cut précédent sur 6 cuts sur 8 ;
- au cut 1203, le premier clic donne 1 321 mm, 120 mm de moins que le voisin :
  c'est l'autre champignon. L'opérateur essaie les autres combinaisons pendant
  près de 30 s et retient 1 437,8 mm (voisin : 1 441,2) ;
- le réglage fin suit ensuite les points, même s'il éloigne de l'écartement du
  voisin (1205 : 1 440 → 1 426 mm) ;
- en fin de session, retours 1204 → 1203 → 1202 → 1203 → 1204 → 1205, sans
  modification : une vérification visuelle de la continuité.

Lecture : **la continuité dit où chercher et quel champignon est le bon ;
les points disent où poser.** L'écartement du voisin sert à reconnaître un
mauvais champignon (−120 mm), jamais à fixer la position finale. C'est la
garde du §3.6 du n°3, pas une cible.

### 7.2 Le moteur 4.7.6 sur la même série

Aucun cut juste : 7 visites sans entrée (rail droit sans instantané qualifié
autour de la pose ESV), le reste en abstention ou refusé par l'écartement.
Rejoué avec tous les nuages de la visite, depuis la pose ESV, il pose le rail
gauche sur l'autre champignon (136 à 188 mm de l'humain) et s'abstient : la
cause décrite au §3.4 du n°3, sur une nouvelle partie.

### 7.3 Amorce par continuité : mesure

> **Chiffres remplacés au §7.8.** Cette première mesure a été relue par un
> modèle indépendant le jour même : références jugées sans la fraîcheur du
> banc, points comptés deux fois, ancres ordonnées par numéro de cut et non
> par ordre de visite (KI-045). Elle est conservée pour la traçabilité.

Même moteur, mêmes points ; seul change le départ. Le rail de départ est
translaté, dans son plan de profil, jusqu'à la droite tirée des deux cuts
d'ancrage les plus proches (3 numéros au plus). Points : tous les nuages de la
première visite, qui approchent une capture faite autour du départ ; le témoin
reçoit exactement les mêmes.

| Session (cuts jugés) | Départ ESV (témoin) | Ancres validées par l'opérateur | Chaînage sur le moteur | Relais opérateur |
|---|---|---|---|---|
| Partie 22 (8) | 0 juste · 0 faux | 4 · 1¹ | 6 · 1¹ | 6 · 1¹ |
| Partie 20, Natif longue (199) | 109 · **11** | **135 · 2** | 123 · 5 | 130 · 6 |
| Partie 20, Natif courte (52) | 41 · 0 | 41 · 0 | 41 · 0 | 41 · 0 |
| Partie 19, relecture du Pilote (25) | 11 · 0 | 12 · 0 | 12 · 0 | 10 · 0 |
| **Total (284)** | **161 · 11** | **192 · 3** | 182 · 6 | 187 · 7 |

¹ le cut 1205, discuté au §7.6.

Sur la session longue, le départ est à 3,1 mm médian de la pose humaine
(p90 9,2 mm) avec les ancres de l'opérateur, contre 4,5 mm (p90 121 mm) depuis
la pose ESV. Sur les 9 cuts faux de la courbe (398 à 435), **7 deviennent
justes et 2 passent en abstention** (412, 435) — et non « les 9 deviennent
justes », comme écrit d'abord ; 5 cuts justes depuis la pose ESV passent en
abstention ou en refus d'écartement. Restent faux 241 (aucun cut validé à moins
de 3 numéros : départ ESV) et 983 (15 mm, déjà connu).

### 7.4 Le chaînage ne corrige pas une ancre fausse

Le moteur s'appuie sur ses propres cuts appliqués, sans aucune position
humaine. Session longue : 398 est posé faux depuis la pose ESV (160 mm), puis
400, 403 et 404 sont posés faux sur son prolongement (178 à 250 mm) ; 409,
faux depuis la pose ESV. Correction après relecture : ces trois cuts n'ont
chacun qu'**une seule ancre** (400 ← 398, 403 ← 400, 404 ← 403), et les cinq
faux du chaînage étaient **déjà faux depuis la pose ESV**. La mesure montre
qu'une ancre fausse est réutilisée et empêche la correction ; elle ne montre
pas que le chaînage crée des erreurs nouvelles. La règle du §3.7 du n°3
(« un cut résolu par continuité ne sert pas de voisin ») reste une prudence,
pas un résultat démontré.

### 7.5 Le relais par l'opérateur

Ancres : cuts appliqués depuis la pose ESV, et cuts NON appliqués que
l'opérateur corrige au fil du lot ; un cut résolu par continuité n'est jamais
ancre. Moins bon que prévu : 130 justes et **6 faux** sur la session longue,
pour 63 corrections servant d'ancre. Cause : quand trois cuts de suite sont
résolus par continuité, aucune ancre ne reste à 3 numéros et le moteur repart
de la pose ESV (403, 412, 241, 983), puis un départ ESV faux devient ancre
(404 sur 403). **Le point faible n'est pas l'amorce, c'est le retour silencieux
à la pose ESV au milieu d'une zone difficile.** À corriger avant toute
conception du Pilote : ne jamais repartir de la pose ESV quand une ancre, même
plus lointaine, existe ; ou différer ; et contrôler tout départ ESV contre les
cuts voisins acceptés.

### 7.6 Limites

- Les points de l'étude incluaient des nuages capturés après les gestes de
  l'opérateur. Contrairement à ce qui était écrit, donner les mêmes points au
  témoin ne suffit pas à neutraliser le biais : le moteur filtre les points
  autour de son départ, qui diffère entre les deux. Corrigé au §7.8 : seuls
  les points capturés à la pose ESV avant le premier geste sont utilisés.
- Partie 22 : 8 cuts jugés, une seule série. Elle compte comme première des
  « deux autres parties comportant des appareils de voie » du §3.7 du n°3, pas
  comme la preuve.
- Cut 1205 : le moteur place le rail gauche à 11 mm de l'opérateur ; à la pose
  de l'opérateur, les points du flanc sont à 8,9 mm du gabarit contre 2 à 3 mm
  d'habitude. À relire avant de le compter faux.
- L'étude déplace le départ ; le §3.5 du n°3 ajoutait une graine (`uSeeds`)
  sans déplacer l'origine. Les deux mesurent la même idée par deux moyens.

### 7.7 Conséquence pour le chantier « garde de continuité »

Le chantier du §6.8 du n°6 devient **« continuité de voie »**, une seule
prédiction — la droite des cuts d'ancrage — pour deux usages :

1. **amorce** : chercher autour de la prédiction plutôt qu'autour de la pose
   ESV quand des ancres existent ;
2. **garde** : différer un cut dont le résultat s'écarte de la prédiction
   au-delà d'un seuil (30 mm au §6.6 du n°6).

Règles d'ancrage, tirées des §7.4 et 7.5 : un cut résolu par continuité ne sert
jamais d'ancre ; un départ depuis la pose ESV au milieu d'une zone ancrée est
contrôlé par la garde avant de pouvoir servir d'ancre ; faute d'ancre, le cut
est différé plutôt que posé depuis une pose ESV lointaine. Aucune cible
d'écartement : la garde d'écartement reste la seule règle de paire.

Préalables inchangés du §3.7 du n°3 (deuxième partie à appareils de voie,
observation dans le Pilote avant toute application). Le relais par l'opérateur
change le déroulé du Pilote : décision de la direction.

Sur le §2 : avec des ancres validées, et après correction (§7.8), 141 cuts
justes et 3 faux sur 252 contre 118 et 6 depuis la pose ESV ; l'engagement de
90 % dépend désormais de l'ancrage. Sur le §15 : P5 toujours ouvert en
conditions réelles.

### 7.8 Relecture indépendante et chiffres corrigés

La première étude (§7.3 à 7.5) a été relue le 23/09 par un modèle indépendant,
sans accès aux archives, sur le code et les relevés. Ses constats, vérifiés :

| Constat | Effet | Suite |
|---|---|---|
| Référence « stricte » sans fraîcheur ni association du banc ; des références non fiables servaient d'ancre (418) | biais | jugement par `referenceFor` ; ancres aux mêmes règles |
| Toutes les captures d'une visite concaténées : points comptés deux fois (17 579 lignes pour 8 637 points au cut 1198) | gonfle les seuils du moteur | une capture par côté, doublons retirés |
| Nuages capturés après les gestes de l'opérateur ; visibilité inconnue admise | fuite possible | pose ESV exacte, avant le premier changement de rail, visibilité prouvée |
| Contours pris sur un nuage d'une autre pose | décisions faussées possibles | contours de la capture retenue, même pose |
| Ancres ordonnées par numéro de cut, pas par ordre de visite ; repère non contrôlé | scénario non reproduit | ordre réel (`visitIndex`), même partie et même repère |
| Chaînage : une seule ancre, faux déjà faux au témoin | surinterprétation | §7.4 corrigé |
| Garde à 30 mm non testée | variante incomplète | évaluée ci-dessous |
| « 9 faux deviennent justes » : 7 justes, 2 abstentions | affirmation fausse | §7.3 corrigé |
| Seuil latéral arrondi, vertical ignoré | sans effet mesuré | erreurs brutes, vertical rapporté |

Nouvelle mesure : `tools/continuity-seed-study.cjs --mode observer`, qui rejoue
exactement le calcul de la 4.7.7 (`src/continuity-observer.js`) et le témoin
depuis la pose ESV sur **la même entrée**, jugés aux règles du banc
(`audit/continuity-observer-2026-09-23.json`) :

| Session (cuts jugés) | Départ ESV | Départ par continuité | Continuité + garde 30 mm |
|---|---|---|---|
| Partie 22 (7) | 0 juste · 0 faux | 4 · 2¹ | 4 · 1 · 1 différé |
| Partie 20, Natif longue (177) | 80 · **6** | **98 · 1** | 98 · 1 |
| Partie 20, Natif courte (52) | 31 · 0 | 31 · 0 | 31 · 0 |
| Partie 19, relecture du Pilote (16) | 7 · 0 | 8 · 0 | 8 · 0 |
| **Total (252)** | **118 · 6** | **141 · 3** | 141 · 2 |

¹ 1204 et 1205, à 11,3 et 11,5 mm : juste au-delà du seuil, là où le départ ESV
s'abstient. 1203 n'est plus une ancre (référence de minutage incertain), d'où
une extrapolation sur 2 cuts pour 1204.

Ce qui tient : sur la session longue, les 5 cuts faux de la courbe depuis la
pose ESV (398, 400, 402, 405, 409) deviennent justes ; le seul faux restant
(983, 14,4 mm) l'est aussi depuis la pose ESV. Transitions : 5 faux → juste,
16 abstentions ou refus → juste, 3 justes → abstention ou refus. Les chiffres
bruts baissent (entrée plus stricte), l'écart entre les deux départs demeure.
Ce qui ne tient pas : la session courte ne gagne rien (pose ESV déjà bonne) ;
sur la partie 22, deux erreurs marginales apparaissent. Temps moteur par
calcul : 0,7 à 1,2 s médian, p90 jusqu'à 2,1 s.

### 7.9 Décision : 4.7.7, observation en Natif

Décision de la direction du 23/09 (D-036) : la 4.7.7 calcule en Natif, à la fin
de chaque première visite, la proposition par continuité aux règles du §7.8,
et la consigne dans la visite sans l'appliquer ni l'afficher. Mesure attendue :
une collecte Natif sur une autre partie à appareils de voie. Règle d'arrêt :
plus de cuts faux par continuité que depuis la pose ESV rejouée sur la même
entrée.

## Amendement n°8 — première collecte 4.7.7 : la continuité mesurée sur le terrain

**23 septembre 2026.** Élément nouveau : la session Natif 4.7.7 de l'après-midi
(`banane-data`, `collections/2026-09-23_v4.7.7_/`) : partie 24, 210 visites,
176 cuts en **20 séries** de 3 à 27 cuts réparties de 764 à 8457, chaque série
commencée quelques cuts avant sa zone ; relevés
`audit/continuity-observer-2026-09-23-p24.json` et
`audit/continuity-parity-2026-09-23-p24.json`.

### 8.1 L'extension a calculé ce qu'elle devait, sans gêner la collecte

- Session complète : 2 037 nuages déclarés, tous présents.
- Un bloc `continuityObservation` sur chacune des 176 premières visites :
  122 calculés, 51 sans ancre (dont les 20 premiers cuts de série), 3 sans
  points utilisables.
- **Parité : 176 blocs sur 176 reproduits à l'identique hors ligne**
  (ancres, entrée, prédiction, statuts et deltas).
- Temps moteur dans le service worker : **255 ms médian, p90 368 ms, max
  550 ms**.
- Santé de collecte : 0 événement perdu, 0 échec d'envoi, file au plus à 24
  (94 et 33 sur les sessions 4.7.6 du matin), niveau complet de bout en bout ;
  instantané initial qualifié pour 83 % / 74 % des rails (82–89 % / 73–79 % en
  4.7.6). KI-046 : aucun effet mesuré.

### 8.2 Continuité contre pose ESV, même entrée, jugé aux règles du banc

| Partie 24, 105 cuts jugés | Justes | Faux | Abstention | Refus d'écartement |
|---|---|---|---|---|
| Départ depuis la pose ESV | 59 | **0** | 29 | 17 |
| Départ par continuité | **68** | **0** | 30 | 7 |

Transitions : 9 refus d'écartement → justes (766, 771–773, 1827–1830, 2560 :
des grappes, là où la pose ESV mène le moteur sur un champignon voisin),
3 abstentions → justes, 3 justes → abstention ou refus. Précision des justes
inchangée : latéral médian 1,3 mm dans les deux cas (p90 5,1 → 4,7 mm),
vertical 0,9 → 0,8 mm. Écart des justes à la prédiction : 4,4 mm médian,
p90 9,3, max 23,3 : la garde à 30 mm n'aurait rien changé. 34 cuts non jugés
faute de référence (26 sans pose finale, 8 à intentions multiples).

**Règle d'arrêt de D-036 : non déclenchée** (0 faux contre 0).

### 8.3 Bilan des mesures de continuité, entrée corrigée

| | Cuts jugés | Départ ESV | Continuité |
|---|---|---|---|
| 23/09 matin, parties 19, 20, 22 (§7.8) | 252 | 118 justes · 6 faux | 141 · 3 |
| 23/09 après-midi, partie 24 (terrain 4.7.7) | 105 | 59 · 0 | 68 · 0 |
| **Total** | **357** | **177 · 6** | **209 · 3** |

Sur le §3.7 du n°3 : la mesure sur deux autres parties à appareils de voie est
faite (parties 22 et 24), sous réserve que les zones de la partie 24 en soient.
Prochaine étape prévue par ce paragraphe : l'observation dans le Pilote, sur
un lot complet relu en Natif — ou, selon la décision de la direction, l'assistant
Natif. Sur le §2 : la continuité ajoute des cuts justes sans faux, mais les
abstentions (30 sur 105) restent le premier frein à la couverture.

## Amendement n°9 — décider sur le lot

**23 septembre 2026.** Éléments nouveaux : les deux audits à mi-parcours
(`audit/mi-parcours/`), les décisions D-037 et D-038, et l'étude
`audit/lot-choice-2026-09-23.json` (`tools/lot-choice-study.cjs`).

### 9.1 Ce qui change

1. **Règle levée.** Le §3.5 du n°3 limitait la continuité à « déplacer la
   fenêtre ». Elle peut désormais **choisir**, parmi les minima locaux que le
   moteur calcule déjà, celui que la voie prédit, aux conditions de l'étude :
   ancres = cuts appliqués du lot confirmés par la garde de continuité (30 mm)
   ou résolus par la voie à 10 mm au plus de la prédiction ; minimum seul à
   15 mm latéraux et 20 mm verticaux de la prédiction ; au moins 15 points de
   dessus et 3 de flanc sous le gabarit ; calage de convention ; **les deux
   rails** ; écartement dans le contrat, en admissibilité seulement.
   Le critère de choix est la POSITION du champignon prédite par la voie,
   jamais un écartement : l'invariant 1 du §7 est inchangé.
2. **Objectif intermédiaire** (D-037) : 80 % des cuts distincts de chaque lot
   Pilote complet de validation, 0 faux ; 90 % reste le cap du §2.
3. **Définitions de mesure** (D-038) : dénominateur, faux latéral OU vertical
   au-delà de 10 mm, périmètre explicite, partie tenue à l'écart.

### 9.2 Pourquoi

Hors ligne, sans aucune position humaine, sur 722 cuts (392 jugés) :

| Pilote | Cuts appliqués | Justes | Faux |
|---|---|---|---|
| Départ depuis la pose ESV | 45,2 % | 199 | 7 |
| Décision sur le lot, deux passages | 56,0 % | 254 | 4 |
| Décision sur le lot, un seul passage | 53,3 % | 242 | 5 |

Le choix par la voie a résolu 48 cuts, dont 30 jugés : **0 faux**. Les 4 faux
restants viennent du premier passage (241, 409, 983 : cuts isolés que la garde
ne peut contredire) et de la fenêtre déplacée (407). Hors cuts sans capture
avant geste — propres à la collecte Natif —, la couverture atteint 66,7 %.

### 9.3 Mise en œuvre

Dans l'ordre du plan (`PLAN_4.8.md`) : **4.7.8 en observation dans le Pilote**
(calculé, consigné, jamais appliqué), avec journal des candidats et
qualification instrumentée par côté ; activation en 4.7.9 seulement après la
décision D2, sur mesure terrain. Deux passages visés (reprise des différés en
fin de lot), un seul passage mesuré en parallèle. Point ouvert pour tenir le
0 faux : les cuts faux isolés du premier passage.

Sur le §2 : la décision sur le lot est sûre mais ne suffit pas à 80 % sur ces
données ; la mesure terrain de la 4.7.8 départagera observation et choix. Sur
le §15 : P2 toujours à mesurer (session F2).

## Amendement n°10 — la décision sur le lot appliquée dans le Pilote

**24 septembre 2026.** Éléments nouveaux : les lots Pilote relus des parties 31
(4.7.8 et 4.7.9) et 34 (4.7.11), les lots de la partie 33 (4.7.10), la
livraison du chantier 2 (`audit/chantiers/faux-isoles.md`) et les décisions de
la direction D-040 à D-045.

### 10.1 Ce qui change

1. **Relecture** (D-040). Une visite de relecture d'au moins 0,5 s sans
   correction ni validation vaut acceptation de la pose vue ; retouchée sans
   validation, elle n'est pas jugeable. C4 porte sur les cuts validés et
   acceptés ; C2 sur les seuls cuts validés. C'est la convention des
   opérateurs ; elle ne change aucun seuil.
2. **Activation** (D-041, D-042). La décision sur le lot du n°9 **commande**
   dans le Pilote depuis la 4.7.10, en **un seul passage** : chaque cut est
   décidé à son ouverture, avec pour appuis les cuts déjà placés du même lot ;
   le second passage (reprise des différés) n'est pas construit. Premier
   passage gardé à 30 mm ; reprise depuis la voie ; choix par la voie, y
   compris à un seul appui. Réglage de lot « Observer seulement » : le Pilote
   de la 4.7.9. `src/engine.js` n'est pas modifié : `Engine.apply()` garde ses
   contrôles (état ESV relu, écartement avant commande, relecture à 1 mm).
3. **Vue d'ESV** (D-043). Le Pilote place un rail en cliquant dans la vue
   qu'ESV centre sur ce rail (±0,2 unité de scène). Depuis la 4.7.11, une
   position de la décision sur le lot hors de cette vue n'est pas commandée :
   le cut est différé. Atteindre ces positions (recadrage, clic en deux temps)
   est **hors 4.8**. Conséquence déclarée : sur une partie où ESV part loin des
   rails, la couverture est bornée par la vue (partie 33 : 78 %).
4. **Garde de paire** (D-044, chantier 2). Un premier passage dont un rail est
   repêché par S1 et dont le calage de convention est hors domaine sur l'un des
   deux rails est différé, et ne devient pas appui ; en retirant un appui, elle
   change aussi les décisions des cuts suivants (relecture indépendante,
   D-046). C'est un curseur nouveau du §8 ; son bilan est tenu
   (`audit/garde-paire-verification-2026-09-24.md`). Une paire retirée par la
   garde de continuité n'est jamais appliquée par un repli (KI-053, 4.7.14).
5. **Lecture de C4** (D-042). La direction tolère un faux isolé de la décision
   sur le lot ; un faux du **même type** qui se reproduit sur des lots relus
   (deux ou trois fois) déclenche un correctif, mesuré sur toutes les données
   relues ; tout faux d'un autre type est analysé et rapporté aussitôt. Zéro
   faux reste la cible. **À trancher par la direction pour la sortie** : le
   seuil C4 des lots de validation — zéro faux strict, ou faux isolés expliqués
   tolérés. Dans les deux cas, chaque faux des lots de validation est nommé dans
   le rapport de sortie avec son type.
6. **Interface** (D-045). Le chantier B part de la proposition « La ligne »
   (`design/ui-next-claude/`) ; les invariants du test H du §14 restent la
   condition.
7. **Report en 4.9.** Chantier 1 (revenir à un cut), appuis sur les cuts
   voisins déjà validés (le Pilote irait lire leur pose lui-même), recadrage de
   la vue d'ESV.

### 10.2 Pourquoi

| Lot relu | Pilote placé | Faux / jugés | Décision sur le lot |
|---|---|---|---|
| Partie 31, lot 2 (4.7.9, observation) | 47 / 78 | 0 / 45 | 72 / 78 ; 1 / 69 (7026, choix à un seul appui) |
| Partie 34 (4.7.11, appliquée, jamais vue) | 73 / 96 (76 %) | 1 / 71 (1834, premier passage du moteur) | 0 / 14 sur les cuts qu'elle a placés |
| Partie 34, règles de la 4.7.12 (rejeu) | 73 / 96 | **0 / 71** : la garde de paire diffère 1834 | — |

Sur toutes les données relues, en un seul passage
(`audit/choix-un-appui-2026-09-24.md`) : reprise depuis la voie 0 faux sur 36 ;
choix à deux appuis 0 sur 23 ; choix à un appui 1 sur 19. La garde de paire
arrête 241 et 409 au banc Natif et 1834 sur le terrain, sans perdre de cut
juste mesuré. Restent au banc Natif de la partie 20 : 398 et 402 (premiers
passages sans aucun appui) et 983 (15 mm).

### 10.3 Impact

Sur le §2 et l'objectif intermédiaire du n°9 (80 %) : aucun lot complet de
validation n'est encore relu ; les lots arrêtés donnent 76 à 92 % selon la
partie, la vue d'ESV bornant les parties où ESV part loin des rails. Sur le
§15 : P2 reste à mesurer et bloque toute cible d'erreur publiée ; P5 est
mesuré.

## Amendement n°11 — bilan des curseurs de la décision sur le lot

**24 septembre 2026.** Éléments nouveaux : le bilan chiffré des curseurs de la
décision sur le lot (`audit/curseurs-lot-2026-09-24.md`), la décision de la
direction sur `chainMm` et sur la relecture ciblée (D-047, D-048), le lot
4.7.12 de la partie 35.

### 11.1 Ce qui change

1. **C5 pour la décision sur le lot.** Les curseurs ajoutés par le n°9 entrent
   au §8 avec leur bilan : garde de continuité `guardMm` 30 mm, choix
   `chooseMm` 15 mm, reprise appui `chainMm`, voisinage `gap` 3 cuts, `anchors`
   2 appuis, filtres du choix (`minTop`, `minFace`, `maxDzMm`), garde de paire.
   Chacun est déplacé seul, un cran de chaque côté, décision rejouée en un seul
   passage sur tout ce qui a été relu.
2. **`chainMm` desserré de 10 à 15 mm** (4.7.15, D-047) : +4 justes, aucun faux,
   aucun juste perdu. Les autres curseurs sont conservés avec leur coût mesuré.
3. **Relecture ciblée** (D-048). Un lot peut être relu sur une zone seulement.
   C4 et la précision portent alors sur les cuts de la zone ; le rapport donne
   la zone et la part du lot jugée, sans extrapoler. Le seuil C4 de sortie
   reste à trancher (n°10, point 5).
4. **Cahier 4.9 ouvert** (`BANANE_4.9_CAHIER.md`, brouillon non signé) : il
   réunit les chantiers renvoyés à la 4.9 (n°10, point 7 ; D-043) et l'outil de
   décentrage de la caméra d'ESV demandé par la direction (D-049). Rien n'y
   entre dans le périmètre de la 4.8.
5. **Garde d'écartement voisin activée, `minTop` du choix à 5** (4.7.16,
   D-050). La garde du §3.6 du n°3, proposée pour mesure, est mesurée
   (`audit/ecartement-voisin-2026-09-24.md`) et activée à 20 mm : garde
   seulement, jamais cible. Avec `minTop` 5 : +13 justes, −1 faux (7026),
   aucun juste perdu sur tout ce qui a été relu.

### 11.2 Pourquoi

| Curseur | Essais | Meilleur écart à la base (652 décidés, 485 justes, 4 faux) |
|---|---|---|
| `chainMm` 10 | 5, 15 | 15 : +4 justes, 0 faux |
| `guardMm` 30 | 20, 40 | 40 : +1 juste ; 20 : −4 |
| `chooseMm` 15 | 10, 20 | 10 : −1 faux (7026), −5 justes |
| `gap` 3 | 2, 4 | 4 : +3 justes, +1 faux (1835) |
| `anchors` 2 | 3 | 3 : −1 juste |

Les faux restants (398, 402 sans appui ; 983 à 3,9 mm de la voie ; 7026
isolé) ne dépendent d'aucun de ces curseurs dans les plages essayées.

### 11.3 Impact

Sur C5 : chaque curseur de la décision sur le lot a son bilan ; `minTop` du
choix desserré à 5 (D-050) ; `minTop` du moteur reste sans bilan de
desserrage (n°5).
Sur C1 : la partie 35 (4.7.12, jamais vue, non relue) donne 203 cuts traités
sur 233 (87 %), dont 32 placés par la décision sur le lot, sans erreur.

## Amendement n°12 — relecture 4.7.16 et tests d'acceptation

**24 septembre 2026.** Éléments nouveaux : la relecture indépendante de la
4.7.13 à la 4.7.16 (`audit/chantiers/relecture-4716.md`), la matrice
d'acceptation du chantier 5 (`tests/ACCEPTANCE_MATRIX.md`,
`audit/chantiers/acceptation.md`), l'étude des faux sans appui du chantier 7
(`audit/chantiers/faux-sans-appui.md`).

### 12.1 Ce qui change

1. **Un appui est un cut posé** (4.7.18, D-052, KI-057). Le n°10 disait « avec
   pour appuis les cuts déjà placés du même lot » ; le code retenait toute
   décision. Désormais, l'appui proposé attend que ses positions soient
   commandées, appliquées et le cut validé. Règle consignée (`anchorRule`),
   rejouée à l'identique ; lots antérieurs rejoués avec leur règle.
2. **Aucune pose humaine par « Réessayer »** (KI-055) : refusé si les rails ont
   bougé pendant la pause (§10, §14 I).
3. **C5 rapporté avec C1 à C4** dans chaque section du rapport d'acceptation
   (§14 G, KI-056).
4. **Faux de premier passage sans appui : observer** (D-051). Aucune des six
   gardes mesurées ne les arrête sans perdre de justes.
5. **Matrice d'acceptation** : 44 exigences, contrôlée à chaque banc ; une
   exigence perdue, un essai cité inexistant ou une exigence déclarée couverte
   sur un essai « todo » font échouer le banc.

### 12.2 Pourquoi

Partie 35 : 8951, différé (cible hors de la vue), était appui de 8952 et 8953.
Sur le banc relu, la règle « cut posé » ne change aucun faux et coûte deux cuts
justes (partie 2 : 115, 116), qui ne tenaient qu'à des appuis hors de la vue
(`audit/appui-pose-2026-09-24.md`).

### 12.3 Conditions de la version candidate 4.8.0-rc

1. Un lot Pilote **neuf** (partie jamais utilisée pour régler), **complet** et
   **relu**, sous la 4.7.18 ou plus récente. C1 compté sur les cuts distincts,
   C4 évaluable seulement si 80 % au moins des appliqués sont jugés. La
   définition d'un lot complet est à trancher par la direction.
2. Le seuil C4 de sortie, à trancher par la direction : zéro faux strict, ou
   faux isolés expliqués tolérés (n°10, point 5).
3. P2 : 30 cuts replacés à l'aveugle ; sans lui, aucun chiffre d'erreur (C2)
   n'est publié.
4. Les neuf choix `minTop` 5 non jugés, à juger sur le terrain, en priorité en
   zone de faible densité et d'appareils de voie.
5. Contrôle visuel du §14 H dans Edge ; banc vert sur le commit candidat ;
   paquet reproductible.

## Amendement n°13 — passages à niveau et reprise des différés

**25 septembre 2026.** Éléments nouveaux : deux lots 4.7.18 relus (parties 2 et
3, deux reliquats), la méthode de l'opérateur au passage à niveau (7801–7806),
le banc du lecteur « passage à niveau » (`audit/passage-niveau-lecteur-2026-09-25.md`).

### 13.1 Ce qui change

1. **Passage à niveau** : sur un cut que la chaîne diffère, la paire lue à
   l'ornière est posée si l'écartement est dans le contrat (admissibilité
   seulement), si elle passe la garde d'écartement voisin et, avec des appuis,
   si elle tombe à 10 mm de la voie. Jamais sur un cut décidé. Le lecteur ne lit
   que la capture : ni pose humaine, ni écartement cible.
2. **Voie encadrée** : un cut qui a des appuis posés des deux côtés est prédit
   par une courbe passant par eux.
3. **Lot « Reprise des différés »** : il part des cuts posés et validés par le
   lot précédent autour de ses différés. Un appui reste un cut posé par le
   Pilote (n°12, point 1) ; aucun cut validé à la main.
4. **Arrêt au dernier cut du lot** : le Pilote ne valide pas le dernier cut ;
   ESV ne passe plus à la partie suivante.

### 13.2 Pourquoi

Au banc relu, le lecteur en dernier recours décide 45 cuts de plus (36 jugés,
1 faux à 10,5 mm) sans perdre de juste ; utilisé en arbitre, il en retirait 43.
Les différés d'un reliquat viennent du manque d'appuis, pas des règles : les
82 cuts de la partie 3 sont décidés de la même façon sous les règles de la
4.7.12, de la 4.7.14 et de la 4.7.18.

### 13.3 Question ouverte à la direction

Les cuts isolés d'un reliquat n'ont d'appui que dans des cuts **validés à la
main**. Les utiliser serait faire entrer une pose humaine dans la décision :
c'est un amendement au §14 I, à décider (cahier 4.9 ou avant).

## Amendement n°14 — voisins validés, interface H, fin de partie

**25 septembre 2026.** Éléments nouveaux : trois lots Pilote du 25/09 (partie 9
en 4.7.18 et 4.7.19, partie 6 en 4.7.19), la décision de la direction sur la
question ouverte du n°13 (§13.3), et la 4.7.20.

### 14.1 Ce qui change

1. **§14 I amendé (D-054)** : des cuts **voisins** validés par l'opérateur
   peuvent servir d'appuis à la voie de la décision sur le lot, sous garde de
   cohérence (au moins trois voisins alignés à 8 mm sur les deux rails, à ±5
   cuts). Jamais la pose du cut décidé, jamais un écartement cible : le contrat
   [1405, 1470] mm reste une admissibilité. La garde est dans
   `src/lot-decision.js`, partagée par le banc et le Pilote ; la source terrain
   des voisins validés reste à trouver (ESV n'ouvre que le « cut non validé
   suivant »).
2. **Interface H** (piste « Sans le skill », retenue le 24/09) livrée en 4.7.20
   sur les trois modes, avec ses animations et le bandeau dans ESV. Les
   invariants de l'interface (§ Phase 3 du plan) sont tenus : politique
   effective affichée, « Différés : N » fidèle, incertitude de navigation
   visible avec son cut, aucun bouton présenté comme réussi sur un simple
   accusé, écartement sans valeur centrale.
3. **Fin de partie** (KI-061) : une validation qui emmène ESV hors du lot clôt le
   lot ; le passage d'ESV à la partie suivante est constaté, pas empêché.
4. **Exports en segments** (KI-060) : chaque segment se relit seul ; les exports
   antérieurs sont réparés à la lecture.
5. **P2** : outil de mesure prêt (`tools/p2-plancher.cjs`) ; la session terrain
   (30 cuts replacés à l'aveugle) reste à faire.
6. **C5** : `gaugeGap`, `gaugeCount` et `crossingVoieMm` ont leur bilan de
   variation (D-055) : aucun effet sauf `crossingVoieMm` 15 (+1 cut juste) ;
   conservés. Restent sans bilan : `frameGap`, `frameAnchors` (reprise seulement)
   et `validatedMinInliers` (sans source terrain).

### 14.2 Pourquoi

Partie 9 (4.7.18, 346 cuts ; puis 4.7.19 sur les différés) : 276 cuts posés sur
348 (79,3 %) ; les 12 cuts de passage à niveau annoncés par le rejeu de la
4.7.19 sont appliqués à l'identique sur le terrain ; 36 cuts perdus hors de la
vue en fin de partie (KI-051). Partie 6 (reliquat, 1,1 cut par suite) : 73/125,
52 différés tous « sans appui » ; une reprise dans la même page n'en prendrait
que 3 : dans un reliquat, les seuls appuis possibles sont les voisins validés à
la main (partie 19, au banc : 57 % → 79 %, 0 faux).

### 14.3 Impact

Sur le §2 et l'objectif intermédiaire (80 %) : la partie 9, jamais réglée, est
à 79,3 % sur le terrain, 82,5 % avec une reprise dans la même page, 89 à 93 %
hors fin de partie hors vue ; elle deviendra le premier lot de validation dès
sa relecture. Sur le §15 : P2 toujours à mesurer (outil prêt).

## Amendement n°15 — interface Pilote simplifiée, bornes remplies, premier lot complet

**26 septembre 2026.** Éléments nouveaux : la relecture Natif de la partie 9
(`audit/relecture-p9-2026-09-26.md`), le premier lot 4.7.20 (partie 12, menée à
sa borne) et les demandes de la direction sur l'interface (D-056).

### 15.1 Ce qui change

1. **Interface Pilote (D-056)** : réglages du lot fixes (différer, appliquer,
   tenter), cerveau de placement actif par défaut, détails ouverts par défaut,
   Assisté retiré de l'interface. Les politiques effectives d'un lot en cours
   restent affichées (cahier 4.7 §10).
2. **Bornes remplies par Banane** : premier cut = cut affiché ; dernier cut =
   fin retenue pour la partie, sinon « fin de partie » (le lot se clôt quand
   ESV quitte la partie). Modifiables.
3. **Lot complet** : un lot arrêté sur sa borne (`stoppedAtEnd`) compte comme
   complet dans le rapport d'acceptation et le rapport de sortie.
4. **KI-062 corrigé** : un nouveau lot démarre après un lot arrêté sans
   réinstaller l'extension.

### 15.2 Pourquoi

Terrain du 26/09 : l'opérateur réactivait les mêmes réglages à chaque lot, et
ne pouvait plus lancer de lot sans réinstaller après un arrêt. Dans un lot
Pilote GCV1, les réglages retirés ne changeaient pas les positions posées.

### 15.3 Impact

Sur le §2 : premier lot mené à sa borne (partie 12, 79,2 %), à relire pour
compter en validation. Partie 9 relue en partie : 2 faux sur 66 appliqués
jugés ; C4 non évaluable (25 % jugés). Moteur et décision sur le lot inchangés.

## Amendement n°16 — examen de sortie : relecture de la partie 12, décisions D-057

**26 septembre 2026.** Éléments nouveaux : la relecture Natif complète du lot
4.7.20 de la partie 12 (`audit/relecture-p12-2026-09-26.md`) et les décisions
de la direction sur les conditions de la version candidate (§12.3, D-057).

### 16.1 Ce qui change

1. **Seuil C4 de sortie** (§12.3, point 2) : faux isolés expliqués tolérés ;
   zéro faux reste la cible. Chaque faux des lots de validation est nommé
   avec son type dans le rapport de sortie.
2. **Lot complet** (§12.3, point 1) : un lot arrêté en cours de route compte
   pour ce qu'il a traité, s'il est relu ; un reliquat de la même partie est
   compté par partie.
3. **P2** (§12.3, point 3) : reporté en 4.9. C2 est publié comme écart à la
   relecture de l'opérateur, sans plancher humain, et dit comme tel.
4. **Rotation réglage / validation** : la mesure d'une partie neuve est
   consignée avant tout réglage ; parties 9 et 12 consignées, elles passent au
   réglage pour la 4.8.5.
5. **Reportés en 4.8.5** : voisins validés en dernier recours (D-054), pistes
   des faux 7738 et 7743, biais vertical aux passages à niveau (au banc).
6. **Contrôle Edge** (§12.3, point 5) : fait par la direction ; bouton
   d'ouverture d'ESV redessiné en blanc, discret.

### 16.2 Pourquoi

La partie 12 est le premier lot de validation complet et entièrement jugé :
84 appliqués, 84 jugés, 2 faux (7738, choix à un appui, 13,5 mm ; 7743,
premier passage à 27,7 mm de la voie, 22,2 mm), 0 hors contrat. Parties 9 et
12 ensemble : 4 faux sur 161 jugés, tous isolés et typés.

### 16.3 Impact

C3, C4 (seuil D-057) et C5 tenus ; C2 publié sans plancher. **C1** : 79,2 %
(partie 12) et 79,3 % (partie 9, par partie), sous l'objectif intermédiaire
de 80 % d'un cut sur la partie 12 : à accepter explicitement par la direction.
KI-063 (arrêts du Pilote 4.7.21) : trois causes, corrigées en 4.8.0
(`audit/interruptions-4721-2026-09-26.md`).

## Amendement n°17 — Ariane 4.8.0 : noms, ESV rafraîchi, sortie

**27 septembre 2026.** Décision de la direction D-058.

- **Noms** : Ariane (extension), Écho (ex-Natif), Orbite (ex-Pilote) ;
  identifiants internes et formats de données inchangés.
- **§12.3, point 1** : C1 retenu comme atteint à 79 % (parties 9 et 12).
- **ESV lent** : pause et consigne F5 ; après F5, « Reprendre » revient au
  cut du lot et rattache le lot à la nouvelle page (KI-063, option 1).
- **Sortie** : C1, C3, C4 et C5 tenus, C2 publié sans plancher
  (`audit/rapport-sortie-4.8.md`). Livraison définitive après confirmation
  des photos et de la vidéo du menu par la direction.

