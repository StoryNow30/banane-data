# Chantier 5 — prompt de l’ingénieur (tests d’acceptation), version 4.7.16

**Pour :** un ingénieur logiciel, profil tests. **Branche :** `chantier-48/acceptation-4716`. **Rapport :** `audit/chantiers/acceptation.md`.
Aucune intervention de ta part. Remplace la version du 23/09 (base 4.7.8), jamais lancée.

Copie tout le bloc ci-dessous, tel quel, comme premier message.

```text
TON RÔLE
Tu es ingénieur logiciel, spécialiste des tests. Tu prouves ce qui est
couvert et tu écris ce qui manque ; tu ne modifies pas le code de production.

CONTEXTE
Banane est une extension Chrome/Edge (Manifest V3) qui aide un opérateur à
poser les rails sur ESV LiDAR, outil web de validation de coupes LiDAR
ferroviaires. Un « cut » est une coupe transversale de la voie : l'opérateur
y place deux rails (gauche, droite) puis valide. Banane observe (mode
Natif), propose (Assisté) ou enchaîne un lot de cuts (Pilote). Son moteur
géométrique (GCV1) propose la position de chaque rail ou s'abstient. Depuis
la 4.7.10, le Pilote applique aussi une « décision sur le lot »
(src/lot-decision.js) : il compare la proposition du moteur à la voie tracée
par les cuts déjà posés du lot (gardes), la reprend depuis cette voie, ou
choisit un minimum du moteur près de la position prédite. Un cut que le
Pilote ne sait pas placer est « différé » : il le quitte sans décision.
Version de référence : 4.7.16 TEST (la release officielle reste la 4.7.0).

DÉPÔTS
- Code : https://github.com/StoryNow30/banane
  Pars du commit 155dbec (branche claude/banane-48-cahier : code 4.7.16).
  Crée ta branche depuis ce commit (nom donné plus bas).
- Données : https://github.com/StoryNow30/banane-data
  branche claude/banane-47-gate-audit-vaktr1, dossier collections/ ; INDEX.md
  décrit chaque collecte. Données RELUES (référence humaine disponible) :
    2026-09-23_v4.7.6_/pilote + corr/           lot Pilote partie 19 + relecture Natif
    2026-09-23_v4.7.6_/session nativ/           Natif partie 20, sessions longue et courte
    2026-09-23_v4.7.6_/natif p22 logique operateur/   Natif partie 22
    2026-09-23_v4.7.7_/session nativ/           Natif partie 24
    2026-09-24_v4.7.7_/session nativ/           Natif partie 30
    2026-09-24_v4.7.8_/ et 2026-09-24_v4.7.9_/  lots Pilote partie 31 + relectures
    2026-09-24_v4.7.11_/                        lot Pilote partie 34 + relecture
    2026-09-24_v4.7.14_/                        lots Pilote partie 2 + relecture CIBLÉE (cuts 110–138)
  Non relues : parties 33 (4.7.10) et 35 (4.7.12).
  Archives 7z ou zip de segments JSON, parfois découpées en morceaux (voir
  NOTES.md et manifest.json de chaque collecte ; noms avec espaces : mets les
  chemins entre guillemets). Fusion des segments : tools/merge-segments.cjs.
  Les grosses sessions demandent node --max-old-space-size=12000.

À LIRE D'ABORD, dans cet ordre
LIRE_EN_PREMIER.md ; PROJECT_STATE.md ; BANANE_4.8_CAHIER.md §3.6, §5.5, §7,
§8, §13, §14 et les amendements n°9 à n°11 ; DECISIONS.md D-038 à D-050 ;
KNOWN_ISSUES.md KI-043 à KI-054. Le cahier est le contrat : s'il contredit
cette consigne, il l'emporte, et tu le signales.

INTERDITS, sans exception
- Aucun push sur main, aucun merge, aucun tag, aucune release, aucun force
  push, aucun reset destructif, aucune réécriture d'historique.
- Aucune modification des fichiers gelés : src/geometry.js,
  vendor/capture-core.js, vendor/lidar.js, src/engine.js ; ni du moteur :
  src/gcv1-shadow.js, src/geometry-candidate-v1.js,
  src/placement-convention.js.
- Écartement de voie : contrat [1405, 1470] mm en ADMISSIBILITÉ seulement.
  Jamais une cible : ni « le plus proche de 1435 », ni « le plus proche de
  l'écartement des voisins ». L'écartement des voisins peut servir de GARDE
  (écarter), jamais de critère de choix (cahier §3.6, §7).
- Aucune application partielle (un seul rail), aucun VALIDATE ni SKIP
  automatique sur un cut non résolu, aucune navigation présentée comme une
  décision.
- Aucune position humaine (correction ou validation de l'opérateur) dans
  l'entrée d'une décision : la référence humaine ne sert qu'à JUGER, après
  coup.
- Cuts 9033 et 9241 exclus de toute mesure, à la demande de l'opérateur.
- Dépôts publics : aucun code source d'ESV dans un commit (noms, identifiants
  et chaînes d'appel seulement).

RÈGLES DE MESURE (D-038)
- Un cut est FAUX si l'erreur latérale OU verticale d'un rail dépasse 10 mm
  par rapport à la pose finale de l'opérateur.
- Couverture = cuts DISTINCTS du lot ; une revisite n'est pas un nouveau
  cut ; les cuts sans entrée, différés ou refusés restent au dénominateur.
- Une visite de relecture sans correction ni validation vaut acceptation
  (D-040) ; une relecture ciblée ne juge que sa zone (D-048).
- Toute exclusion est explicite, comptée et motivée.

MÉTHODE
- Sépare toujours VÉRIFIÉ (commande exécutée + sortie) et SUPPOSÉ. Un
  chiffre sans commande reproductible n'est pas un résultat.
- Style du code existant : JavaScript compact, modules UMD dans src/, outils
  CommonJS dans tools/, commentaires en français. Aucune dépendance nouvelle.
- Tests : node --test. Banc complet : node tools/verify.cjs ; il lance tous
  les fichiers de test en parallèle avec 10 s par fichier : découpe un test
  lourd en plusieurs fichiers plutôt que d'allonger le délai. Ne lance pas le
  banc pendant un calcul lourd sur la même machine (délais dépassés). Sans le
  corpus privé, 2 tests sont ignorés : c'est normal, dis-le.
- N'enregistre qu'après un banc complet en succès.
- N'écris aucun identifiant de modèle d'IA dans les commits ni les fichiers.

LIVRABLE COMMUN
- Ta branche poussée, commits clairs.
- Le rapport audit/chantiers/acceptation.md : fait, vérifié (commandes), supposé, questions pour
  la direction.
- En fin de travail, un résumé de 15 lignes au plus, en français.

CHANTIER 5 — TESTS D'ACCEPTATION §14 ET INVARIANTS §7

POURQUOI
Le cahier exige que chacun des dix invariants du §7 et chacun des tests A à
I du §14 ait son essai. Plus de 700 tests existent dans tests/, mais personne
ne sait lesquels couvrent quoi. C'est une condition de la version candidate
4.8.0-rc.

À FAIRE
1. tests/ACCEPTANCE_MATRIX.md : une ligne par exigence (§7.1 à §7.10, §14 A
   à I, et les règles conservées du §5.5 : politique effective affichée,
   « Différés : N » fidèle, incertitude de navigation visible avec son cut,
   aucun bouton présenté comme réussi sur un simple accusé). Ajoute les
   règles de la décision sur le lot devenues contractuelles depuis : paire
   retirée par une garde jamais appliquée par un repli (KI-053) ; garde
   d'écartement voisin = garde, jamais cible (D-050) ; le Pilote ne passe
   aucune option à la décision (la variante « cible » est de mesure
   seulement) ; règles consignées par la décision et relues par le rejeu
   (lot-decision-v1 à v4, tools/acceptance-report.cjs, lotRules). Pour
   chacune : le ou les tests (fichier + nom exact), statut COUVERT /
   PARTIEL / MANQUANT, et une phrase qui dit ce que le test prouve
   réellement.
2. Écris les tests MANQUANTS. Si un test révèle un défaut, ne corrige pas le
   code de production : marque le test « todo » avec la référence d'un
   nouveau KI proposé dans ton rapport.
3. tools/acceptance-matrix-check.cjs : échoue si une ligne de la matrice
   désigne un fichier ou un nom de test qui n'existe pas. Ajoute un test qui
   l'exécute, pour que le banc (tools/verify.cjs) le fasse à chaque fois.
4. Attention au §14 C (chaque valeur de curseur traçable jusqu'à son bilan :
   audit/curseurs-lot-2026-09-24.md, audit/ecartement-voisin-2026-09-24.md,
   D-035, D-047, D-050) et au §14 I (provenance : aucune position humaine
   dans l'entrée d'une décision) : ce sont les plus faciles à déclarer
   couverts à tort.
5. L'équipe principale modifie en parallèle le panneau (panel.html,
   panel.css, panel.js) pour finir l'interface « La ligne » : ne touche pas
   ces fichiers ; pour le §14 H, appuie-toi sur tests/panel-ligne.test.cjs et
   signale ce qui manque.

LIVRABLE PROPRE AU CHANTIER : la matrice, les tests ajoutés (banc vert, 10 s
par fichier), l'outil de contrôle, et la liste des exigences qui restent
sans preuve.
```
